# Recipe Meal Planner

A public recipe-sharing app with a drag-to-plan weekly meal grid and
auto-generated shopping lists. Built with Next.js (App Router) + Supabase
(Postgres, Auth) + Tailwind.

## What's here

```
app/
  page.tsx                 Home
  recipes/page.tsx         Browse + search public recipes
  recipes/new/page.tsx     Create a recipe (form -> Supabase insert)
  recipes/[id]/page.tsx    Recipe detail (ingredients + steps)
  planner/page.tsx         Weekly meal grid + shopping list generator
  login/page.tsx           Magic link + Google OAuth
  auth/callback/route.ts   Exchanges OAuth code for a session
components/
  RecipeForm.tsx           Recipe creation form (client)
  FavoriteButton.tsx       Favorite toggle (client)
  PlannerGrid.tsx          7-day grid, click-to-add, shopping list (client)
lib/supabase/
  client.ts                Browser Supabase client
  server.ts                Server Component / Route Handler Supabase client
middleware.ts              Refreshes the auth session cookie on each request
supabase/schema.sql        Full Postgres schema + RLS policies
```

## Setup

### 1. Create a Supabase project
Go to supabase.com, create a new project, and grab your **Project URL**
and **anon public key** from Project Settings -> API.

### 2. Run the schema
Open the Supabase SQL Editor and paste in the contents of
`supabase/schema.sql`, then run it. This creates all tables, the
auto-profile-on-signup trigger, and Row Level Security policies.

### 3. (Optional) Enable Google OAuth
In Supabase: Authentication -> Providers -> Google. If you skip this,
just remove the "Continue with Google" button from `app/login/page.tsx`
and use magic-link email sign-in only — it works out of the box.

### 4. Configure env vars
```bash
cp .env.local.example .env.local
# fill in NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
```

### 5. Install and run
```bash
npm install
npm run dev
```
Visit http://localhost:3000.

### 6. Deploy
Push to GitHub, import the repo in Vercel, add the same two env vars
in Vercel's project settings, deploy. Also add your Supabase auth
redirect URL (`https://your-app.vercel.app/auth/callback`) in
Supabase -> Authentication -> URL Configuration.

## How the data model works

- `recipes` is the core table. `is_public` controls visibility — RLS
  policies enforce that private recipes are only readable by their owner.
- Ingredients are deduplicated in a shared `ingredients` table (so
  "garlic" from two different recipes is the same row), linked via
  `recipe_ingredients` with per-recipe quantity/unit.
- `meal_plans` is one row per user per week (`week_start` = that week's
  Monday), and `meal_plan_items` places specific recipes on specific
  day/slot combinations.
- The shopping list is generated client-side: it pulls all
  `recipe_ingredients` for every recipe currently in the week's plan and
  sums quantities per ingredient+unit.

## What to build next (roughly in priority order)

1. **Image upload** — wire up Supabase Storage for recipe photos
   (currently `photo_url` is just a text column with no upload UI).
2. **Recipe editing/deleting** — the `[id]/edit` route exists as a
   folder but has no page yet; reuse `RecipeForm` with initial values.
3. **Tags/filtering** — `tags` and `recipe_tags` tables exist in the
   schema but aren't wired into the UI yet. Add a tag picker to
   `RecipeForm` and filter chips to `/recipes`.
4. **Servings scaler** — multiply ingredient quantities client-side
   when the user changes the serving count on the detail page.
5. **True drag-and-drop** on the planner grid (currently click-to-add
   via a modal) — a good excuse to learn `@dnd-kit/core`.
6. **Public profile pages** — `/u/[username]` showing a user's public
   recipes, using the `profiles` table that already exists.
