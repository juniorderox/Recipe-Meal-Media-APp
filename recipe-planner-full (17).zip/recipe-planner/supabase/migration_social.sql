-- ============================================================
-- Migration: social features (likes, comments, follows) + photo storage
-- Run this in the Supabase SQL Editor AFTER you've already run schema.sql once.
-- ============================================================

create table public.likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, recipe_id)
);
create index on public.likes (recipe_id);

create table public.comments (
  id uuid primary key default gen_random_uuid(),
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);
create index on public.comments (recipe_id);

create table public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id != following_id)
);
create index on public.follows (following_id);

alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.follows enable row level security;

create policy "likes are publicly readable" on public.likes
  for select using (true);
create policy "users manage their own likes" on public.likes
  for all using (user_id = auth.uid());

create policy "comments are publicly readable" on public.comments
  for select using (true);
create policy "signed in users can comment" on public.comments
  for insert with check (user_id = auth.uid());
create policy "users can delete their own comments" on public.comments
  for delete using (user_id = auth.uid());

create policy "follows are publicly readable" on public.follows
  for select using (true);
create policy "users manage their own follows" on public.follows
  for all using (follower_id = auth.uid());

-- ============================================================
-- Storage policies for recipe photo uploads.
-- IMPORTANT: create the bucket FIRST via Storage -> New bucket ->
-- name it exactly "recipe-photos" -> check "Public bucket" -> Create.
-- Then run this part.
-- ============================================================
create policy "recipe photos are publicly readable"
  on storage.objects for select
  using (bucket_id = 'recipe-photos');

create policy "signed in users can upload recipe photos"
  on storage.objects for insert
  with check (bucket_id = 'recipe-photos' and auth.uid() is not null);

create policy "users can delete their own recipe photos"
  on storage.objects for delete
  using (bucket_id = 'recipe-photos' and owner = auth.uid());
