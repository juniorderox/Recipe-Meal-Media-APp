-- ============================================================
-- Recipe Meal Planner — Postgres schema (run in Supabase SQL editor)
-- ============================================================

-- Profiles: one row per auth user, public-facing display info
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  avatar_url text,
  created_at timestamptz not null default now()
);

-- Recipes
create table public.recipes (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text,
  photo_url text,
  cook_time_minutes int,
  servings int not null default 4,
  is_public boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.recipes (owner_id);
create index on public.recipes (is_public);

-- Steps live on the recipe as an ordered array of text for MVP simplicity.
-- (Normalizing into a recipe_steps table is a natural v2 exercise.)
alter table public.recipes add column steps text[] not null default '{}';

-- Ingredients master list (shared/deduped across recipes, e.g. "garlic", "flour")
create table public.ingredients (
  id uuid primary key default gen_random_uuid(),
  name text unique not null
);

-- Join table: which ingredients + quantities belong to which recipe
create table public.recipe_ingredients (
  id uuid primary key default gen_random_uuid(),
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  ingredient_id uuid not null references public.ingredients(id) on delete restrict,
  quantity numeric,
  unit text, -- e.g. 'g', 'cup', 'tbsp', null for countable items
  note text  -- e.g. "finely chopped"
);
create index on public.recipe_ingredients (recipe_id);

-- Tags (cuisine, diet, meal type — all just tags, filterable)
create table public.tags (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  category text not null default 'general' -- 'cuisine' | 'diet' | 'meal_type' | 'general'
);

create table public.recipe_tags (
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  tag_id uuid not null references public.tags(id) on delete cascade,
  primary key (recipe_id, tag_id)
);

-- Favorites
create table public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, recipe_id)
);

-- Meal plans: one per user per week (keyed by the Monday date of that week)
create table public.meal_plans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  week_start date not null,
  created_at timestamptz not null default now(),
  unique (user_id, week_start)
);

-- Items placed on the weekly grid
create table public.meal_plan_items (
  id uuid primary key default gen_random_uuid(),
  meal_plan_id uuid not null references public.meal_plans(id) on delete cascade,
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  day_of_week int not null check (day_of_week between 0 and 6), -- 0 = Monday
  meal_slot text not null default 'dinner' -- 'breakfast' | 'lunch' | 'dinner' | 'snack'
);
create index on public.meal_plan_items (meal_plan_id);

-- ============================================================
-- Social features: likes, comments, follows
-- ============================================================
create table public.likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, recipe_id)
);
create index on public.likes (recipe_id);

create table public.comments (
  id uuid primary key default gen_random_uuid(),
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);
create index on public.comments (recipe_id);

create table public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id != following_id)
);
create index on public.follows (following_id);

alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.follows enable row level security;

create policy "likes are publicly readable" on public.likes
  for select using (true);
create policy "users manage their own likes" on public.likes
  for all using (user_id = auth.uid());

create policy "comments are publicly readable" on public.comments
  for select using (true);
create policy "signed in users can comment" on public.comments
  for insert with check (user_id = auth.uid());
create policy "users can delete their own comments" on public.comments
  for delete using (user_id = auth.uid());

create policy "follows are publicly readable" on public.follows
  for select using (true);
create policy "users manage their own follows" on public.follows
  for all using (follower_id = auth.uid());

-- ============================================================
-- Storage: recipe photo uploads
-- Run this AFTER creating a public bucket named "recipe-photos"
-- in the Supabase dashboard (Storage -> New bucket -> check "Public bucket").
-- ============================================================
create policy "recipe photos are publicly readable"
  on storage.objects for select
  using (bucket_id = 'recipe-photos');

create policy "signed in users can upload recipe photos"
  on storage.objects for insert
  with check (bucket_id = 'recipe-photos' and auth.uid() is not null);

create policy "users can delete their own recipe photos"
  on storage.objects for delete
  using (bucket_id = 'recipe-photos' and owner = auth.uid());
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, username)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'user_name', split_part(new.email, '@', 1)) || '_' || substr(new.id::text, 1, 4)
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- Row Level Security
-- ============================================================
alter table public.profiles enable row level security;
alter table public.recipes enable row level security;
alter table public.recipe_ingredients enable row level security;
alter table public.recipe_tags enable row level security;
alter table public.favorites enable row level security;
alter table public.meal_plans enable row level security;
alter table public.meal_plan_items enable row level security;

-- Profiles: anyone can read, only the owner can write
create policy "profiles are publicly readable" on public.profiles
  for select using (true);
create policy "users can update their own profile" on public.profiles
  for update using (auth.uid() = id);
create policy "users can insert their own profile" on public.profiles
  for insert with check (auth.uid() = id);

-- Recipes: public recipes readable by everyone; private only by owner
create policy "public recipes are readable by anyone" on public.recipes
  for select using (is_public = true or owner_id = auth.uid());
create policy "users can insert their own recipes" on public.recipes
  for insert with check (owner_id = auth.uid());
create policy "users can update their own recipes" on public.recipes
  for update using (owner_id = auth.uid());
create policy "users can delete their own recipes" on public.recipes
  for delete using (owner_id = auth.uid());

-- Recipe ingredients/tags follow the parent recipe's visibility
create policy "ingredients readable if recipe readable" on public.recipe_ingredients
  for select using (
    exists (select 1 from public.recipes r where r.id = recipe_id and (r.is_public or r.owner_id = auth.uid()))
  );
create policy "owner manages recipe ingredients" on public.recipe_ingredients
  for all using (
    exists (select 1 from public.recipes r where r.id = recipe_id and r.owner_id = auth.uid())
  );

create policy "tags readable if recipe readable" on public.recipe_tags
  for select using (
    exists (select 1 from public.recipes r where r.id = recipe_id and (r.is_public or r.owner_id = auth.uid()))
  );
create policy "owner manages recipe tags" on public.recipe_tags
  for all using (
    exists (select 1 from public.recipes r where r.id = recipe_id and r.owner_id = auth.uid())
  );

-- Favorites: users manage their own
create policy "users see their own favorites" on public.favorites
  for select using (user_id = auth.uid());
create policy "users manage their own favorites" on public.favorites
  for all using (user_id = auth.uid());

-- Meal plans: private to the user
create policy "users manage their own meal plans" on public.meal_plans
  for all using (user_id = auth.uid());
create policy "users manage their own meal plan items" on public.meal_plan_items
  for all using (
    exists (select 1 from public.meal_plans mp where mp.id = meal_plan_id and mp.user_id = auth.uid())
  );

-- ingredients/tags master tables: readable by everyone, insertable by any signed-in user
alter table public.ingredients enable row level security;
alter table public.tags enable row level security;
create policy "ingredients readable by anyone" on public.ingredients for select using (true);
create policy "signed in users can add ingredients" on public.ingredients for insert with check (auth.uid() is not null);
create policy "tags readable by anyone" on public.tags for select using (true);
create policy "signed in users can add tags" on public.tags for insert with check (auth.uid() is not null);
