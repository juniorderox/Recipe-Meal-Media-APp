-- ============================================================
-- Migration: realtime updates + recipe collections
-- ============================================================

-- Enable realtime broadcast for live-updating counts and notifications.
-- Wrapped so re-running this migration doesn't error if already enabled.
do $$
begin
  alter publication supabase_realtime add table public.likes;
exception when duplicate_object then null;
end $$;

do $$
begin
  alter publication supabase_realtime add table public.comments;
exception when duplicate_object then null;
end $$;

do $$
begin
  alter publication supabase_realtime add table public.notifications;
exception when duplicate_object then null;
end $$;

-- ============================================================
-- Collections (boards) for organizing saved recipes
-- ============================================================
create table public.collections (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now()
);
create index on public.collections (owner_id);

create table public.collection_recipes (
  collection_id uuid not null references public.collections(id) on delete cascade,
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  added_at timestamptz not null default now(),
  primary key (collection_id, recipe_id)
);

alter table public.collections enable row level security;
alter table public.collection_recipes enable row level security;

create policy "users manage their own collections" on public.collections
  for all using (owner_id = auth.uid());

create policy "users manage recipes in their own collections" on public.collection_recipes
  for all using (
    exists (select 1 from public.collections c where c.id = collection_id and c.owner_id = auth.uid())
  );
