-- ============================================================
-- Migration: profile editing (bio + avatar uploads)
-- ============================================================

alter table public.profiles add column if not exists bio text;

-- ============================================================
-- Storage policies for profile picture uploads.
-- IMPORTANT: create the bucket FIRST via Storage -> New bucket ->
-- name it exactly "avatars" -> check "Public bucket" -> Create.
-- Then run this part.
-- ============================================================
create policy "avatars are publicly readable"
  on storage.objects for select
  using (bucket_id = 'avatars');

create policy "signed in users can upload their own avatar"
  on storage.objects for insert
  with check (bucket_id = 'avatars' and auth.uid() is not null);

create policy "users can update their own avatar"
  on storage.objects for update
  using (bucket_id = 'avatars' and owner = auth.uid());

create policy "users can delete their own avatar"
  on storage.objects for delete
  using (bucket_id = 'avatars' and owner = auth.uid());
