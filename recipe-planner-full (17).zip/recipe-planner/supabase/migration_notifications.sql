-- ============================================================
-- Migration: notifications + muting
-- Run this in the Supabase SQL Editor after your previous migrations.
-- ============================================================

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid not null references public.profiles(id) on delete cascade,
  type text not null check (type in ('like', 'comment', 'follow')),
  recipe_id uuid references public.recipes(id) on delete cascade,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index on public.notifications (recipient_id, created_at desc);

alter table public.notifications enable row level security;

create policy "users see their own notifications" on public.notifications
  for select using (recipient_id = auth.uid());

create policy "users can mark their own notifications read" on public.notifications
  for update using (recipient_id = auth.uid());

create policy "signed in users can create notifications for their own actions" on public.notifications
  for insert with check (actor_id = auth.uid());

-- ============================================================
create table public.muted_users (
  muter_id uuid not null references public.profiles(id) on delete cascade,
  muted_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (muter_id, muted_id),
  check (muter_id != muted_id)
);

alter table public.muted_users enable row level security;

create policy "users manage their own mutes" on public.muted_users
  for all using (muter_id = auth.uid());

-- ============================================================
create table public.blocked_users (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id != blocked_id)
);

alter table public.blocked_users enable row level security;

-- A user can manage rows where they're the blocker, and can also SEE rows
-- where they're the one being blocked (so their feed can exclude that person too).
create policy "users manage their own blocks" on public.blocked_users
  for all using (blocker_id = auth.uid());

create policy "users can see if they've been blocked" on public.blocked_users
  for select using (blocked_id = auth.uid());
