-- ============================================================
-- Migration: onboarding usernames, multi-photo recipes, reports
-- ============================================================

-- Existing users keep their current username as-is (default true = "already set").
-- New signups get username_set = false so they're prompted to pick their own.
alter table public.profiles add column if not exists username_set boolean not null default true;

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, username, display_name, avatar_url, username_set)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'user_name', split_part(new.email, '@', 1)) || '_' || substr(new.id::text, 1, 4),
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    coalesce(new.raw_user_meta_data->>'avatar_url', new.raw_user_meta_data->>'picture'),
    false
  );
  return new;
end;
$$ language plpgsql security definer;

-- ============================================================
-- Multiple photos per recipe (recipes.photo_url stays as the "cover" photo)
-- ============================================================
create table public.recipe_photos (
  id uuid primary key default gen_random_uuid(),
  recipe_id uuid not null references public.recipes(id) on delete cascade,
  url text not null,
  position int not null default 0
);
create index on public.recipe_photos (recipe_id, position);

alter table public.recipe_photos enable row level security;

create policy "recipe photos readable if recipe readable" on public.recipe_photos
  for select using (
    exists (select 1 from public.recipes r where r.id = recipe_id and (r.is_public or r.owner_id = auth.uid()))
  );
create policy "owner manages recipe photos" on public.recipe_photos
  for all using (
    exists (select 1 from public.recipes r where r.id = recipe_id and r.owner_id = auth.uid())
  );

-- ============================================================
-- Reports (recipe or user), stored for later review
-- ============================================================
create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reported_user_id uuid references public.profiles(id) on delete cascade,
  reported_recipe_id uuid references public.recipes(id) on delete cascade,
  reason text not null,
  created_at timestamptz not null default now()
);

alter table public.reports enable row level security;

create policy "users can file their own reports" on public.reports
  for insert with check (reporter_id = auth.uid());
create policy "users can see their own filed reports" on public.reports
  for select using (reporter_id = auth.uid());

-- ============================================================
-- Seed common tags (safe to re-run)
-- ============================================================
insert into public.tags (name, category) values
  ('breakfast', 'meal_type'), ('lunch', 'meal_type'), ('dinner', 'meal_type'),
  ('dessert', 'meal_type'), ('snack', 'meal_type'),
  ('vegan', 'diet'), ('vegetarian', 'diet'), ('gluten-free', 'diet'), ('halal', 'diet'), ('dairy-free', 'diet'),
  ('thai', 'cuisine'), ('myanmar', 'cuisine'), ('chinese', 'cuisine'), ('japanese', 'cuisine'),
  ('italian', 'cuisine'), ('indian', 'cuisine'), ('mexican', 'cuisine'), ('korean', 'cuisine')
on conflict (name) do nothing;
