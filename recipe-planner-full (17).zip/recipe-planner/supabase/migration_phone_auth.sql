-- ============================================================
-- Migration: support phone-only signups (no email) safely
-- ============================================================

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, username, display_name, avatar_url, username_set)
  values (
    new.id,
    coalesce(
      new.raw_user_meta_data->>'user_name',
      split_part(new.email, '@', 1),
      'user'
    ) || '_' || substr(new.id::text, 1, 4),
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    coalesce(new.raw_user_meta_data->>'avatar_url', new.raw_user_meta_data->>'picture'),
    false
  );
  return new;
end;
$$ language plpgsql security definer;
