-- ============================================================
-- Migration: sync real name + avatar from Google/Facebook into profiles
-- ============================================================

alter table public.profiles add column if not exists display_name text;

-- Update the signup trigger so brand-new users get their real name/photo immediately
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, username, display_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'user_name', split_part(new.email, '@', 1)) || '_' || substr(new.id::text, 1, 4),
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    coalesce(new.raw_user_meta_data->>'avatar_url', new.raw_user_meta_data->>'picture')
  );
  return new;
end;
$$ language plpgsql security definer;

-- ============================================================
-- One-time backfill: sync YOUR existing profile with your Google account data
-- (safe to run even if you signed up before this column existed)
-- ============================================================
update public.profiles p
set
  display_name = coalesce(u.raw_user_meta_data->>'full_name', u.raw_user_meta_data->>'name', p.display_name),
  avatar_url = coalesce(u.raw_user_meta_data->>'avatar_url', u.raw_user_meta_data->>'picture', p.avatar_url)
from auth.users u
where p.id = u.id;
