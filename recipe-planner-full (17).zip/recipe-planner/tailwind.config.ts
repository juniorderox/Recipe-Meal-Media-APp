import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#fef6ee",
          100: "#fdead7",
          400: "#f5934a",
          500: "#ef7622",
          600: "#e05d18",
          700: "#b94716",
        },
      },
    },
  },
  plugins: [],
};
export default config;
