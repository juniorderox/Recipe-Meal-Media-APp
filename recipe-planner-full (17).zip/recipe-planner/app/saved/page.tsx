import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import FeedPost from "@/components/FeedPost";
import AddToCollectionButton from "@/components/AddToCollectionButton";

export default async function SavedPage() {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return (
      <div className="text-center py-16 text-neutral-600">
        Sign in to see your saved recipes.
      </div>
    );
  }

  const { data: favoriteRows } = await supabase
    .from("favorites")
    .select("recipe_id, recipes ( id, title, description, photo_url, owner_id, profiles!recipes_owner_id_fkey ( username, avatar_url ) )")
    .eq("user_id", user.id);

  const recipes = (favoriteRows ?? [])
    .map((f: any) => f.recipes)
    .filter(Boolean);

  if (recipes.length === 0) {
    return (
      <div className="text-center py-16">
        <h1 className="text-2xl font-bold mb-2">Nothing saved yet</h1>
        <p className="text-neutral-600 mb-6">
          Tap Save on any recipe in the feed to keep it here.
        </p>
        <Link
          href="/"
          className="rounded-lg bg-brand-500 px-5 py-2.5 text-white font-medium hover:bg-brand-600"
        >
          Browse the Feed
        </Link>
      </div>
    );
  }

  const recipeIds = recipes.map((r: any) => r.id);

  const { data: likeRows } = await supabase
    .from("likes")
    .select("recipe_id, user_id")
    .in("recipe_id", recipeIds);

  const { data: commentRows } = await supabase
    .from("comments")
    .select("recipe_id")
    .in("recipe_id", recipeIds);

  const likeCounts = new Map<string, number>();
  const likedByMe = new Set<string>();
  likeRows?.forEach((row) => {
    likeCounts.set(row.recipe_id, (likeCounts.get(row.recipe_id) ?? 0) + 1);
    if (row.user_id === user.id) likedByMe.add(row.recipe_id);
  });

  const commentCounts = new Map<string, number>();
  commentRows?.forEach((row) => {
    commentCounts.set(row.recipe_id, (commentCounts.get(row.recipe_id) ?? 0) + 1);
  });

  const ownerIds = [...new Set(recipes.map((r: any) => r.owner_id))];
  const { data: followRows } = await supabase
    .from("follows")
    .select("following_id")
    .eq("follower_id", user.id)
    .in("following_id", ownerIds);
  const followingByMe = new Set(followRows?.map((f) => f.following_id));

  return (
    <div className="max-w-xl mx-auto space-y-4">
      <div className="flex items-center justify-between mb-2">
        <h1 className="text-2xl font-bold">Saved</h1>
        <Link href="/collections" className="text-sm text-brand-600 font-medium hover:underline">
          Collections →
        </Link>
      </div>
      {recipes.map((r: any) => (
        <div key={r.id}>
          <FeedPost
            recipeId={r.id}
            title={r.title}
            description={r.description}
            photoUrl={r.photo_url}
            ownerId={r.owner_id}
            ownerUsername={r.profiles?.username ?? "someone"}
            ownerAvatarUrl={r.profiles?.avatar_url ?? null}
            userId={user.id}
            initialLiked={likedByMe.has(r.id)}
            initialLikeCount={likeCounts.get(r.id) ?? 0}
            commentCount={commentCounts.get(r.id) ?? 0}
            initialSaved={true}
            initialFollowing={followingByMe.has(r.owner_id)}
          />
          <div className="mt-2">
            <AddToCollectionButton recipeId={r.id} userId={user.id} />
          </div>
        </div>
      ))}
    </div>
  );
}
