"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function SettingsPage() {
  const router = useRouter();
  const supabase = createClient();

  const [email, setEmail] = useState("");
  const [emailSaving, setEmailSaving] = useState(false);
  const [emailMessage, setEmailMessage] = useState<string | null>(null);

  const [confirmText, setConfirmText] = useState("");
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  async function handleEmailChange(e: React.FormEvent) {
    e.preventDefault();
    setEmailSaving(true);
    setEmailMessage(null);
    const { error } = await supabase.auth.updateUser({ email });
    setEmailSaving(false);
    if (error) {
      setEmailMessage(error.message);
    } else {
      setEmailMessage("Check both your old and new email inboxes to confirm the change.");
    }
  }

  async function handleDelete() {
    if (confirmText !== "DELETE") return;
    setDeleting(true);
    setDeleteError(null);

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      setDeleteError("Not signed in.");
      setDeleting(false);
      return;
    }

    // Deleting the profile row cascades to recipes, comments, likes,
    // favorites, follows, notifications, mutes, and blocks tied to it.
    const { error } = await supabase.from("profiles").delete().eq("id", user.id);

    if (error) {
      setDeleteError(error.message);
      setDeleting(false);
      return;
    }

    await supabase.auth.signOut();
    router.push("/");
    router.refresh();
  }

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Settings</h1>

      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/70 dark:border-neutral-800 shadow-sm p-6">
        <h2 className="font-semibold mb-1">Change email</h2>
        <p className="text-sm text-neutral-500 mb-4">
          You&apos;ll need to confirm this from a link sent to your new address.
        </p>
        <form onSubmit={handleEmailChange} className="flex gap-2">
          <input
            type="email"
            required
            placeholder="new@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="flex-1 rounded-lg border border-neutral-300 px-3 py-2 text-sm"
          />
          <button
            type="submit"
            disabled={emailSaving}
            className="rounded-lg bg-neutral-900 text-white px-4 py-2 text-sm font-medium disabled:opacity-50"
          >
            {emailSaving ? "Saving..." : "Update"}
          </button>
        </form>
        {emailMessage && (
          <p className="text-sm text-neutral-500 mt-2">{emailMessage}</p>
        )}
      </div>

      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-red-200 dark:border-red-900/50 shadow-sm p-6">
        <h2 className="font-semibold text-red-600 mb-1">Delete my data</h2>
        <p className="text-sm text-neutral-500 mb-1">
          This permanently deletes your profile, recipes, comments, likes, saves, and
          follow relationships. It cannot be undone.
        </p>
        <p className="text-xs text-neutral-400 mb-4">
          Note: this removes your data but not your login credentials — deleting the
          underlying account itself requires contacting support directly.
        </p>
        {deleteError && (
          <p className="rounded-lg bg-red-50 text-red-700 text-sm p-3 mb-3">{deleteError}</p>
        )}
        <label className="block text-sm mb-1">
          Type <strong>DELETE</strong> to confirm
        </label>
        <input
          value={confirmText}
          onChange={(e) => setConfirmText(e.target.value)}
          className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm mb-3"
        />
        <button
          onClick={handleDelete}
          disabled={confirmText !== "DELETE" || deleting}
          className="rounded-lg bg-red-600 text-white px-4 py-2 text-sm font-medium disabled:opacity-40"
        >
          {deleting ? "Deleting..." : "Delete my data"}
        </button>
      </div>
    </div>
  );
}
