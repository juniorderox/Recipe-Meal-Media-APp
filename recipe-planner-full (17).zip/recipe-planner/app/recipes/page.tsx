import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function RecipesPage({
  searchParams,
}: {
  searchParams: { q?: string; tag?: string };
}) {
  const supabase = createClient();
  const q = searchParams.q?.trim();
  const activeTag = searchParams.tag?.trim();

  const { data: allTags } = await supabase
    .from("tags")
    .select("id, name, category")
    .order("category");

  let recipeIdsForTag: string[] | null = null;
  if (activeTag) {
    const { data: tagRow } = await supabase
      .from("tags")
      .select("id")
      .eq("name", activeTag)
      .maybeSingle();

    if (tagRow) {
      const { data: taggedRows } = await supabase
        .from("recipe_tags")
        .select("recipe_id")
        .eq("tag_id", tagRow.id);
      recipeIdsForTag = taggedRows?.map((t) => t.recipe_id) ?? [];
    } else {
      recipeIdsForTag = [];
    }
  }

  let query = supabase
    .from("recipes")
    .select("id, title, description, photo_url, cook_time_minutes, servings")
    .eq("is_public", true)
    .order("created_at", { ascending: false });

  if (q) query = query.ilike("title", `%${q}%`);
  if (recipeIdsForTag) query = query.in("id", recipeIdsForTag);

  const { data: recipes, error } = await query;

  return (
    <div>
      <div className="flex items-center justify-between mb-4 gap-4">
        <h1 className="text-2xl font-bold">Recipes</h1>
        <form action="/recipes" className="flex gap-2 flex-1 max-w-xs">
          {activeTag && <input type="hidden" name="tag" value={activeTag} />}
          <input
            type="text"
            name="q"
            defaultValue={q}
            placeholder="Search recipes..."
            className="w-full rounded-full border border-neutral-300 px-4 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400"
          />
          <button
            type="submit"
            className="rounded-full bg-neutral-900 text-white px-4 py-1.5 text-sm hover:bg-neutral-800 transition-colors"
          >
            Search
          </button>
        </form>
      </div>

      {allTags && allTags.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-6">
          <Link
            href={q ? `/recipes?q=${encodeURIComponent(q)}` : "/recipes"}
            className={`text-xs px-3 py-1 rounded-full border ${
              !activeTag
                ? "bg-neutral-900 text-white border-neutral-900"
                : "border-neutral-300 text-neutral-600 hover:bg-neutral-50"
            }`}
          >
            All
          </Link>
          {allTags.map((tag) => (
            <Link
              key={tag.id}
              href={`/recipes?tag=${encodeURIComponent(tag.name)}${q ? `&q=${encodeURIComponent(q)}` : ""}`}
              className={`text-xs px-3 py-1 rounded-full border ${
                activeTag === tag.name
                  ? "bg-brand-500 text-white border-brand-500"
                  : "border-neutral-300 text-neutral-600 hover:bg-neutral-50"
              }`}
            >
              {tag.name}
            </Link>
          ))}
        </div>
      )}

      {error && (
        <p className="text-red-600 text-sm">Error loading recipes: {error.message}</p>
      )}

      {!error && recipes?.length === 0 && (
        <p className="text-neutral-500 text-center py-12">
          {q || activeTag ? "No recipes match that." : "No recipes yet. Be the first to add one!"}
        </p>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-1 sm:gap-3">
        {recipes?.map((r) => (
          <Link
            key={r.id}
            href={`/recipes/${r.id}`}
            className="group relative block aspect-square rounded-lg sm:rounded-xl overflow-hidden bg-neutral-100"
          >
            {r.photo_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={r.photo_url}
                alt={r.title}
                className="h-full w-full object-cover transition-transform duration-200 group-hover:scale-105"
              />
            ) : (
              <div className="h-full w-full flex items-center justify-center text-3xl bg-gradient-to-br from-brand-50 to-neutral-100">
                🍽️
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/0 to-black/0 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
              <div className="text-white">
                <div className="font-semibold text-sm leading-tight">{r.title}</div>
                <div className="text-xs text-white/80 mt-0.5">
                  {r.cook_time_minutes ? `${r.cook_time_minutes} min` : ""}
                  {r.cook_time_minutes && r.servings ? " · " : ""}
                  {r.servings ? `serves ${r.servings}` : ""}
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
