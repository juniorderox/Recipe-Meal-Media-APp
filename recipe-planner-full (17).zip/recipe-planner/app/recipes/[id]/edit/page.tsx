import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import RecipeForm from "@/components/RecipeForm";

export default async function EditRecipePage({
  params,
}: {
  params: { id: string };
}) {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: recipe } = await supabase
    .from("recipes")
    .select(
      `id, title, description, photo_url, cook_time_minutes, servings, steps, owner_id,
       recipe_ingredients ( quantity, unit, ingredients ( name ) ),
       recipe_photos ( url, position ),
       recipe_tags ( tag_id )`
    )
    .eq("id", params.id)
    .single();

  if (!recipe) notFound();
  if (recipe.owner_id !== user.id) redirect(`/recipes/${recipe.id}`);

  const photoUrls = recipe.recipe_photos?.length
    ? recipe.recipe_photos
        .sort((a: any, b: any) => a.position - b.position)
        .map((p: any) => p.url)
    : recipe.photo_url
    ? [recipe.photo_url]
    : [];

  return (
    <div className="max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Edit Recipe</h1>
      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/70 dark:border-neutral-800 shadow-sm p-6">
        <RecipeForm
          mode="edit"
          recipeId={recipe.id}
          initial={{
            title: recipe.title,
            description: recipe.description ?? "",
            cookTime: recipe.cook_time_minutes ? String(recipe.cook_time_minutes) : "",
            servings: String(recipe.servings ?? 4),
            steps: recipe.steps?.length ? recipe.steps : [""],
            photoUrls,
            tagIds: recipe.recipe_tags?.map((rt: any) => rt.tag_id) ?? [],
            ingredients: recipe.recipe_ingredients?.length
              ? recipe.recipe_ingredients.map((ri: any) => ({
                  name: ri.ingredients?.name ?? "",
                  quantity: ri.quantity != null ? String(ri.quantity) : "",
                  unit: ri.unit ?? "",
                }))
              : [{ name: "", quantity: "", unit: "" }],
          }}
        />
      </div>
    </div>
  );
}
