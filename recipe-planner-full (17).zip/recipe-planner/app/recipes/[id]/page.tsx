import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import FavoriteButton from "@/components/FavoriteButton";
import LikeButton from "@/components/LikeButton";
import Comments from "@/components/Comments";
import PostMenu from "@/components/PostMenu";
import FollowButton from "@/components/FollowButton";
import PhotoGallery from "@/components/PhotoGallery";
import IngredientsList from "@/components/IngredientsList";

export default async function RecipeDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const supabase = createClient();

  const { data: recipe, error: recipeError } = await supabase
    .from("recipes")
    .select(
      `id, title, description, photo_url, cook_time_minutes, servings, steps, owner_id,
       recipe_ingredients ( quantity, unit, note, ingredients ( name ) ),
       recipe_photos ( url, position ),
       recipe_tags ( tags ( name ) ),
       profiles!recipes_owner_id_fkey ( username, avatar_url )`
    )
    .eq("id", params.id)
    .single();

  if (recipeError) {
    return (
      <div className="max-w-2xl mx-auto">
        <h1 className="text-xl font-bold text-red-600 mb-2">
          Couldn&apos;t load this recipe
        </h1>
        <pre className="text-sm bg-red-50 text-red-700 p-4 rounded-lg whitespace-pre-wrap">
          {JSON.stringify(recipeError, null, 2)}
        </pre>
      </div>
    );
  }

  if (!recipe) notFound();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { count: likeCount } = await supabase
    .from("likes")
    .select("*", { count: "exact", head: true })
    .eq("recipe_id", recipe.id);

  const ownerUsername = (recipe as any).profiles?.username ?? "someone";
  const ownerAvatarUrl = (recipe as any).profiles?.avatar_url;

  const { data: followRow } = user
    ? await supabase
        .from("follows")
        .select("following_id")
        .eq("follower_id", user.id)
        .eq("following_id", recipe.owner_id)
        .maybeSingle()
    : { data: null };

  // Check both directions: did I block them, or did they block me
  const { data: iBlockedThem } = user
    ? await supabase
        .from("blocked_users")
        .select("blocked_id")
        .eq("blocker_id", user.id)
        .eq("blocked_id", recipe.owner_id)
        .maybeSingle()
    : { data: null };

  const { data: theyBlockedMe } = user
    ? await supabase
        .from("blocked_users")
        .select("blocker_id")
        .eq("blocker_id", recipe.owner_id)
        .eq("blocked_id", user.id)
        .maybeSingle()
    : { data: null };

  if (theyBlockedMe) {
    return (
      <div className="max-w-xl mx-auto text-center py-16 text-neutral-500">
        This recipe isn&apos;t available.
      </div>
    );
  }

  if (iBlockedThem) {
    return (
      <div className="max-w-xl mx-auto text-center py-16">
        <p className="text-neutral-500 mb-4">
          You&apos;ve blocked {ownerUsername}, so their recipes are hidden.
        </p>
        <PostMenu
          recipeId={recipe.id}
          ownerId={recipe.owner_id}
          ownerUsername={ownerUsername}
          userId={user?.id ?? null}
          initialBlocked={true}
        />
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto">
      <Link
        href="/"
        className="text-sm text-neutral-500 hover:text-neutral-800 inline-flex items-center gap-1 mb-4"
      >
        ← Back to feed
      </Link>

      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/70 dark:border-neutral-800 shadow-sm overflow-hidden">
        <PhotoGallery
          photos={
            recipe.recipe_photos?.length
              ? recipe.recipe_photos
                  .sort((a: any, b: any) => a.position - b.position)
                  .map((p: any) => p.url)
              : recipe.photo_url
              ? [recipe.photo_url]
              : []
          }
          alt={recipe.title}
        />

        <div className="p-5">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <Link href={`/u/${encodeURIComponent(ownerUsername)}`} className="flex items-center gap-2.5">
                {ownerAvatarUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={ownerAvatarUrl}
                    alt={ownerUsername}
                    className="h-9 w-9 rounded-full object-cover ring-2 ring-white shadow-sm"
                  />
                ) : (
                  <div className="h-9 w-9 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-sm font-semibold">
                    {ownerUsername[0]?.toUpperCase() ?? "?"}
                  </div>
                )}
              </Link>
              <div>
                <h1 className="text-xl font-bold leading-tight">{recipe.title}</h1>
                <div className="flex items-center gap-2">
                  <Link
                    href={`/u/${encodeURIComponent(ownerUsername)}`}
                    className="text-sm text-neutral-500 hover:underline"
                  >
                    by {ownerUsername}
                  </Link>
                  <FollowButton
                    targetUserId={recipe.owner_id}
                    userId={user?.id ?? null}
                    initialFollowing={!!followRow}
                  />
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <LikeButton
                recipeId={recipe.id}
                ownerId={recipe.owner_id}
                userId={user?.id ?? null}
                initialCount={likeCount ?? 0}
              />
              {user && <FavoriteButton recipeId={recipe.id} userId={user.id} />}
              <PostMenu
                recipeId={recipe.id}
                ownerId={recipe.owner_id}
                ownerUsername={ownerUsername}
                userId={user?.id ?? null}
              />
            </div>
          </div>

          {recipe.description && (
            <p className="text-neutral-600 mt-3">{recipe.description}</p>
          )}
          <div className="mt-2 text-sm text-neutral-500">
            {recipe.cook_time_minutes ? `⏱ ${recipe.cook_time_minutes} min` : ""}
            {recipe.cook_time_minutes && recipe.servings ? "  ·  " : ""}
            {recipe.servings ? `🍽 serves ${recipe.servings}` : ""}
          </div>

          {recipe.recipe_tags && recipe.recipe_tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-3">
              {recipe.recipe_tags.map((rt: any, i: number) => (
                <span
                  key={i}
                  className="text-xs px-2.5 py-1 rounded-full bg-neutral-100 text-neutral-600"
                >
                  {rt.tags?.name}
                </span>
              ))}
            </div>
          )}

          <h2 className="text-base font-semibold mt-6 mb-2">Ingredients</h2>
          <IngredientsList
            baseServings={recipe.servings ?? 1}
            ingredients={
              recipe.recipe_ingredients?.map((ri: any) => ({
                quantity: ri.quantity,
                unit: ri.unit,
                note: ri.note,
                name: ri.ingredients?.name ?? "",
              })) ?? []
            }
          />

          <h2 className="text-base font-semibold mt-6 mb-2">Steps</h2>
          <ol className="list-decimal list-inside space-y-2 text-neutral-800 dark:text-neutral-200 text-sm">
            {recipe.steps?.map((step: string, i: number) => (
              <li key={i}>{step}</li>
            ))}
          </ol>

          <div className="border-t border-neutral-100 mt-6 pt-4">
            <Comments
              recipeId={recipe.id}
              recipeOwnerId={recipe.owner_id}
              userId={user?.id ?? null}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
