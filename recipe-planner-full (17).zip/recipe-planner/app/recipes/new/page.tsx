import RecipeForm from "@/components/RecipeForm";

export default function NewRecipePage() {
  return (
    <div className="max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Share a Recipe</h1>
      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/70 dark:border-neutral-800 shadow-sm p-6">
        <RecipeForm />
      </div>
    </div>
  );
}
