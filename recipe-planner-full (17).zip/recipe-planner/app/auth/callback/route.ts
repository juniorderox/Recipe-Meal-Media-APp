import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = searchParams.get("next") ?? "/recipes";

  if (code) {
    const supabase = createClient();
    const { error, data } = await supabase.auth.exchangeCodeForSession(code);

    if (!error && data.user) {
      // Keep the profile's name/photo in sync with Google/Facebook on every login
      const meta = data.user.user_metadata;
      const displayName = meta?.full_name ?? meta?.name ?? null;
      const avatarUrl = meta?.avatar_url ?? meta?.picture ?? null;

      if (displayName || avatarUrl) {
        await supabase
          .from("profiles")
          .update({
            ...(displayName ? { display_name: displayName } : {}),
            ...(avatarUrl ? { avatar_url: avatarUrl } : {}),
          })
          .eq("id", data.user.id);
      }
    }

    if (!error) {
      return NextResponse.redirect(`${origin}${next}`);
    }
  }

  return NextResponse.redirect(`${origin}/login`);
}
