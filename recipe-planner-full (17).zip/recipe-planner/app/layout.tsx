import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import "./globals.css";
import { createClient } from "@/lib/supabase/server";
import SignOutButton from "@/components/SignOutButton";
import NotificationBell from "@/components/NotificationBell";
import BottomNav from "@/components/BottomNav";
import DarkModeToggle from "@/components/DarkModeToggle";

export const metadata: Metadata = {
  title: "Recipe",
  description: "Share recipes. Like, comment, and save your favorites.",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // Google/Facebook put name + avatar in user_metadata; email sign-in won't have these.
  const displayName =
    user?.user_metadata?.full_name ?? user?.user_metadata?.name ?? user?.email;
  const authAvatarUrl = user?.user_metadata?.avatar_url ?? user?.user_metadata?.picture;

  let myUsername: string | null = null;
  let myAvatarUrl: string | null = null;
  if (user) {
    const { data: myProfile } = await supabase
      .from("profiles")
      .select("username, avatar_url")
      .eq("id", user.id)
      .maybeSingle();
    myUsername = myProfile?.username ?? null;
    myAvatarUrl = myProfile?.avatar_url ?? authAvatarUrl ?? null;
  }

  let notifications: any[] = [];
  if (user) {
    const { data, error: notifFetchError } = await supabase
      .from("notifications")
      .select(
        `id, type, recipe_id, read, created_at,
         actor:profiles!notifications_actor_id_fkey ( username, avatar_url ),
         recipes ( title )`
      )
      .eq("recipient_id", user.id)
      .order("created_at", { ascending: false })
      .limit(20);

    if (notifFetchError) {
      console.error("Failed to fetch notifications:", notifFetchError);
    }

    notifications = (data ?? []).map((n: any) => ({
      ...n,
      recipe_title: n.recipes?.title ?? null,
    }));
  }

  return (
    <html lang="en">
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              try {
                const theme = localStorage.getItem('theme');
                if (theme === 'dark' || (!theme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                  document.documentElement.classList.add('dark');
                }
              } catch (e) {}
            `,
          }}
        />
      </head>
      <body>
        <header className="sticky top-0 z-30 border-b border-neutral-200/70 dark:border-neutral-800 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-md">
          <nav className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
            <Link
              href="/"
              className="text-lg font-bold text-brand-600 tracking-tight flex items-center gap-1"
            >
              🍲 Recipe
            </Link>

            {/* Desktop nav: full links + labels */}
            <div className="hidden sm:flex gap-4 text-sm font-medium text-neutral-600 dark:text-neutral-300 items-center whitespace-nowrap overflow-x-auto">
              <Link href="/recipes" className="hover:text-neutral-900 dark:hover:text-white transition-colors shrink-0">
                Recipes
              </Link>
              <Link href="/search" className="hover:text-neutral-900 dark:hover:text-white transition-colors shrink-0">
                🔍
              </Link>
              {user && (
                <Link href="/saved" className="hover:text-neutral-900 dark:hover:text-white transition-colors shrink-0">
                  Saved
                </Link>
              )}
              {user && (
                <Link href="/collections" className="hover:text-neutral-900 dark:hover:text-white transition-colors shrink-0">
                  Collections
                </Link>
              )}
              <Link href="/recipes/new" className="hover:text-neutral-900 dark:hover:text-white transition-colors shrink-0">
                + New
              </Link>
              <div className="shrink-0">
                <DarkModeToggle />
              </div>

              {user ? (
                <div className="flex items-center gap-1 pl-3 border-l border-neutral-200 dark:border-neutral-700 shrink-0">
                  <div className="shrink-0">
                    <NotificationBell userId={user.id} initialNotifications={notifications} />
                  </div>
                  <Link
                    href={myUsername ? `/u/${encodeURIComponent(myUsername)}` : "#"}
                    className="flex items-center gap-2 shrink-0"
                  >
                    {myAvatarUrl ? (
                      <Image
                        src={myAvatarUrl}
                        alt={displayName ?? "Profile"}
                        width={30}
                        height={30}
                        className="rounded-full ring-2 ring-white dark:ring-neutral-800 shadow-sm shrink-0 h-[30px] w-[30px] object-cover"
                      />
                    ) : (
                      <div className="h-[30px] w-[30px] rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-xs font-semibold shrink-0">
                        {displayName?.[0]?.toUpperCase() ?? "?"}
                      </div>
                    )}
                    <span className="text-neutral-800 dark:text-neutral-100 max-w-[100px] truncate">
                      {displayName}
                    </span>
                  </Link>
                  <Link
                    href="/settings"
                    className="text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 text-xs ml-1 shrink-0"
                  >
                    ⚙️
                  </Link>
                  <div className="shrink-0">
                    <SignOutButton />
                  </div>
                </div>
              ) : (
                <Link
                  href="/login"
                  className="rounded-full bg-neutral-900 text-white px-4 py-1.5 hover:bg-neutral-800 transition-colors shrink-0"
                >
                  Sign in
                </Link>
              )}
            </div>

            {/* Mobile nav: bell + theme toggle, everything else lives in the bottom tab bar */}
            <div className="flex sm:hidden items-center gap-1">
              {user && <NotificationBell userId={user.id} initialNotifications={notifications} />}
              <DarkModeToggle />
            </div>
          </nav>
        </header>

        <main className="mx-auto max-w-5xl px-4 py-6 pb-24 sm:pb-6">{children}</main>

        <BottomNav
          userId={user?.id ?? null}
          username={myUsername}
          avatarUrl={myAvatarUrl}
        />
      </body>
    </html>
  );
}
