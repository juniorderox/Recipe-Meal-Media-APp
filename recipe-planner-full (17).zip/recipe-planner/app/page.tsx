import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import FeedPost from "@/components/FeedPost";

export default async function Home({
  searchParams,
}: {
  searchParams: { sort?: string };
}) {
  const supabase = createClient();
  const sort = searchParams.sort === "trending" ? "trending" : "recent";

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: recipes, error: recipesError } = await supabase
    .from("recipes")
    .select(
      `id, title, description, photo_url, created_at, owner_id,
       profiles!recipes_owner_id_fkey ( username, avatar_url )`
    )
    .eq("is_public", true)
    .order("created_at", { ascending: false })
    .limit(100);

  if (recipesError) {
    return (
      <div className="max-w-2xl mx-auto">
        <h1 className="text-xl font-bold text-red-600 mb-2">
          Couldn&apos;t load the feed
        </h1>
        <pre className="text-sm bg-red-50 text-red-700 p-4 rounded-lg whitespace-pre-wrap">
          {JSON.stringify(recipesError, null, 2)}
        </pre>
      </div>
    );
  }

  const Tabs = (
    <div className="flex gap-1 mb-4 bg-neutral-100 dark:bg-neutral-800 rounded-full p-1 max-w-xs">
      <Link
        href="/"
        className={`flex-1 text-center text-sm font-medium py-1.5 rounded-full transition-colors ${
          sort === "recent"
            ? "bg-white dark:bg-neutral-700 text-neutral-900 dark:text-neutral-50 shadow-sm"
            : "text-neutral-500 dark:text-neutral-400"
        }`}
      >
        For You
      </Link>
      <Link
        href="/?sort=trending"
        className={`flex-1 text-center text-sm font-medium py-1.5 rounded-full transition-colors ${
          sort === "trending"
            ? "bg-white dark:bg-neutral-700 text-neutral-900 dark:text-neutral-50 shadow-sm"
            : "text-neutral-500 dark:text-neutral-400"
        }`}
      >
        🔥 Trending
      </Link>
    </div>
  );

  if (!recipes || recipes.length === 0) {
    return (
      <div className="text-center py-16">
        <h1 className="text-2xl font-bold mb-2">No recipes yet</h1>
        <p className="text-neutral-600 mb-6">Be the first to share one.</p>
        <Link
          href="/recipes/new"
          className="rounded-lg bg-brand-500 px-5 py-2.5 text-white font-medium hover:bg-brand-600"
        >
          Share a Recipe
        </Link>
      </div>
    );
  }

  const { data: muteRows } = user
    ? await supabase.from("muted_users").select("muted_id").eq("muter_id", user.id)
    : { data: [] };
  const mutedIds = new Set(muteRows?.map((m) => m.muted_id));

  const { data: myBlocks } = user
    ? await supabase.from("blocked_users").select("blocked_id").eq("blocker_id", user.id)
    : { data: [] };
  const { data: blockedMeRows } = user
    ? await supabase.from("blocked_users").select("blocker_id").eq("blocked_id", user.id)
    : { data: [] };
  const hiddenIds = new Set([
    ...mutedIds,
    ...(myBlocks?.map((b) => b.blocked_id) ?? []),
    ...(blockedMeRows?.map((b) => b.blocker_id) ?? []),
  ]);

  let visibleRecipes = recipes.filter((r) => !hiddenIds.has(r.owner_id));

  if (visibleRecipes.length === 0) {
    return (
      <div className="max-w-xl mx-auto">
        {Tabs}
        <div className="text-center py-16 text-neutral-500">No posts to show right now.</div>
      </div>
    );
  }

  const recipeIds = visibleRecipes.map((r) => r.id);

  const { data: likeRows } = await supabase
    .from("likes")
    .select("recipe_id, user_id, created_at")
    .in("recipe_id", recipeIds);

  const { data: commentRows } = await supabase
    .from("comments")
    .select("recipe_id")
    .in("recipe_id", recipeIds);

  const { data: favoriteRows } = user
    ? await supabase
        .from("favorites")
        .select("recipe_id")
        .eq("user_id", user.id)
        .in("recipe_id", recipeIds)
    : { data: [] };

  const likeCounts = new Map<string, number>();
  const likedByMe = new Set<string>();
  // "trending" weighs likes from the last 7 days only
  const recentLikeCounts = new Map<string, number>();
  const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;

  likeRows?.forEach((row) => {
    likeCounts.set(row.recipe_id, (likeCounts.get(row.recipe_id) ?? 0) + 1);
    if (new Date(row.created_at).getTime() > sevenDaysAgo) {
      recentLikeCounts.set(row.recipe_id, (recentLikeCounts.get(row.recipe_id) ?? 0) + 1);
    }
    if (user && row.user_id === user.id) likedByMe.add(row.recipe_id);
  });

  const commentCounts = new Map<string, number>();
  commentRows?.forEach((row) => {
    commentCounts.set(row.recipe_id, (commentCounts.get(row.recipe_id) ?? 0) + 1);
  });

  const savedByMe = new Set(favoriteRows?.map((f) => f.recipe_id));

  if (sort === "trending") {
    visibleRecipes = [...visibleRecipes].sort(
      (a, b) => (recentLikeCounts.get(b.id) ?? 0) - (recentLikeCounts.get(a.id) ?? 0)
    );
  }

  visibleRecipes = visibleRecipes.slice(0, 30);

  const ownerIds = [...new Set(visibleRecipes.map((r) => r.owner_id))];
  const { data: followRows } = user
    ? await supabase
        .from("follows")
        .select("following_id")
        .eq("follower_id", user.id)
        .in("following_id", ownerIds)
    : { data: [] };
  const followingByMe = new Set(followRows?.map((f) => f.following_id));

  return (
    <div className="max-w-xl mx-auto">
      {Tabs}
      <div className="space-y-4">
        {visibleRecipes.map((r: any) => (
          <FeedPost
            key={r.id}
            recipeId={r.id}
            title={r.title}
            description={r.description}
            photoUrl={r.photo_url}
            ownerId={r.owner_id}
            ownerUsername={r.profiles?.username ?? "someone"}
            ownerAvatarUrl={r.profiles?.avatar_url ?? null}
            userId={user?.id ?? null}
            initialLiked={likedByMe.has(r.id)}
            initialLikeCount={likeCounts.get(r.id) ?? 0}
            commentCount={commentCounts.get(r.id) ?? 0}
            initialSaved={savedByMe.has(r.id)}
            createdAt={r.created_at}
            initialFollowing={followingByMe.has(r.owner_id)}
          />
        ))}
      </div>
    </div>
  );
}
