import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function SearchPage({
  searchParams,
}: {
  searchParams: { q?: string };
}) {
  const supabase = createClient();
  const q = searchParams.q?.trim();

  let people: any[] = [];
  let recipes: any[] = [];

  if (q) {
    const [{ data: peopleData }, { data: recipesData }] = await Promise.all([
      supabase
        .from("profiles")
        .select("id, username, display_name, avatar_url")
        .or(`username.ilike.%${q}%,display_name.ilike.%${q}%`)
        .limit(20),
      supabase
        .from("recipes")
        .select("id, title, photo_url")
        .eq("is_public", true)
        .ilike("title", `%${q}%`)
        .limit(20),
    ]);
    people = peopleData ?? [];
    recipes = recipesData ?? [];
  }

  return (
    <div className="max-w-xl mx-auto">
      <form action="/search" className="mb-6">
        <input
          type="text"
          name="q"
          defaultValue={q}
          autoFocus
          placeholder="Search people or recipes..."
          className="w-full rounded-full border border-neutral-300 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400"
        />
      </form>

      {!q && <p className="text-neutral-400 text-center py-12">Search for people or recipes.</p>}

      {q && people.length === 0 && recipes.length === 0 && (
        <p className="text-neutral-400 text-center py-12">No results for &quot;{q}&quot;.</p>
      )}

      {people.length > 0 && (
        <div className="mb-6">
          <h2 className="text-sm font-semibold text-neutral-500 mb-2">People</h2>
          <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/70 dark:border-neutral-800 shadow-sm overflow-hidden">
            {people.map((p) => (
              <Link
                key={p.id}
                href={`/u/${encodeURIComponent(p.username)}`}
                className="flex items-center gap-3 px-4 py-3 border-b border-neutral-100 last:border-0 hover:bg-neutral-50"
              >
                {p.avatar_url ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={p.avatar_url} alt={p.username} className="h-10 w-10 rounded-full object-cover" />
                ) : (
                  <div className="h-10 w-10 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-sm font-semibold">
                    {p.username[0]?.toUpperCase() ?? "?"}
                  </div>
                )}
                <div>
                  {p.display_name && (
                    <div className="text-sm font-semibold">{p.display_name}</div>
                  )}
                  <div className="text-sm text-neutral-500">@{p.username}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {recipes.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-neutral-500 mb-2">Recipes</h2>
          <div className="grid grid-cols-3 gap-1 sm:gap-3">
            {recipes.map((r) => (
              <Link
                key={r.id}
                href={`/recipes/${r.id}`}
                className="group relative block aspect-square rounded-lg sm:rounded-xl overflow-hidden bg-neutral-100"
              >
                {r.photo_url ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={r.photo_url}
                    alt={r.title}
                    className="h-full w-full object-cover transition-transform duration-200 group-hover:scale-105"
                  />
                ) : (
                  <div className="h-full w-full flex items-center justify-center text-2xl bg-gradient-to-br from-brand-50 to-neutral-100">
                    🍽️
                  </div>
                )}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
