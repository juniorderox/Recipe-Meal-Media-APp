"use client";

import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const supabase = createClient();

  async function signInWithGoogle() {
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}/auth/callback` },
    });
  }

  return (
    <div className="max-w-sm mx-auto py-16">
      <div className="text-center mb-6">
        <div className="text-3xl mb-1">🍲</div>
        <h1 className="text-xl font-bold">Sign in to Recipe</h1>
        <p className="text-sm text-neutral-500 mt-1">
          Share, like, and save recipes with everyone
        </p>
      </div>

      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/70 dark:border-neutral-800 shadow-sm p-6">
        <button
          onClick={signInWithGoogle}
          className="w-full flex items-center justify-center gap-2 rounded-lg border border-neutral-300 py-2.5 font-medium text-sm hover:bg-neutral-50 transition-colors"
        >
          <span className="text-lg">🔵</span> Continue with Google
        </button>
      </div>
    </div>
  );
}
