import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import CreateCollectionForm from "@/components/CreateCollectionForm";

export default async function CollectionsPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: collections } = await supabase
    .from("collections")
    .select("id, name, collection_recipes ( recipe_id, recipes ( photo_url ) )")
    .eq("owner_id", user.id)
    .order("created_at", { ascending: false });

  return (
    <div className="max-w-xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Collections</h1>
      </div>

      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/70 dark:border-neutral-800 shadow-sm p-4 mb-6">
        <CreateCollectionForm />
      </div>

      {!collections || collections.length === 0 ? (
        <p className="text-neutral-400 text-center py-12">
          No collections yet — create one above to start organizing your saved recipes.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {collections.map((c: any) => {
            const covers = c.collection_recipes
              ?.map((cr: any) => cr.recipes?.photo_url)
              .filter(Boolean)
              .slice(0, 4);
            return (
              <Link
                key={c.id}
                href={`/collections/${c.id}`}
                className="rounded-xl border border-neutral-200/70 dark:border-neutral-800 bg-white dark:bg-neutral-900 overflow-hidden hover:shadow-md transition-shadow"
              >
                <div className="grid grid-cols-2 h-32 bg-neutral-100">
                  {covers && covers.length > 0 ? (
                    covers.map((url: string, i: number) => (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img key={i} src={url} alt="" className="w-full h-full object-cover" />
                    ))
                  ) : (
                    <div className="col-span-2 flex items-center justify-center text-3xl">
                      🔖
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <div className="font-medium text-sm">{c.name}</div>
                  <div className="text-xs text-neutral-400">
                    {c.collection_recipes?.length ?? 0} recipes
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
