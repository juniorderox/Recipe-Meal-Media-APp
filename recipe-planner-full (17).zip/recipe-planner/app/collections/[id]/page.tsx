import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function CollectionPage({
  params,
}: {
  params: { id: string };
}) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: collection } = await supabase
    .from("collections")
    .select("id, name, owner_id")
    .eq("id", params.id)
    .maybeSingle();

  if (!collection) notFound();
  if (collection.owner_id !== user.id) redirect("/collections");

  const { data: items } = await supabase
    .from("collection_recipes")
    .select("recipe_id, recipes ( id, title, photo_url )")
    .eq("collection_id", collection.id);

  return (
    <div className="max-w-xl mx-auto">
      <Link
        href="/collections"
        className="text-sm text-neutral-500 hover:text-neutral-800 inline-flex items-center gap-1 mb-4"
      >
        ← Collections
      </Link>
      <h1 className="text-2xl font-bold mb-6">{collection.name}</h1>

      {!items || items.length === 0 ? (
        <p className="text-neutral-400 text-center py-12">
          Nothing here yet — add recipes from your Saved page.
        </p>
      ) : (
        <div className="grid grid-cols-3 gap-1 sm:gap-3">
          {items.map((item: any) => (
            <Link
              key={item.recipe_id}
              href={`/recipes/${item.recipe_id}`}
              className="group relative block aspect-square rounded-lg sm:rounded-xl overflow-hidden bg-neutral-100"
            >
              {item.recipes?.photo_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={item.recipes.photo_url}
                  alt={item.recipes.title}
                  className="h-full w-full object-cover transition-transform duration-200 group-hover:scale-105"
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center text-2xl bg-gradient-to-br from-brand-50 to-neutral-100">
                  🍽️
                </div>
              )}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
