import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import UserRow from "@/components/UserRow";

export default async function FollowingPage({
  params,
}: {
  params: { username: string };
}) {
  const supabase = createClient();
  const username = decodeURIComponent(params.username);

  const { data: profile } = await supabase
    .from("profiles")
    .select("id, username")
    .eq("username", username)
    .maybeSingle();

  if (!profile) notFound();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: followingRows } = await supabase
    .from("follows")
    .select("following_id, profiles!follows_following_id_fkey ( id, username, avatar_url )")
    .eq("follower_id", profile.id)
    .order("created_at", { ascending: false });

  const followingIds = (followingRows ?? []).map((f) => f.following_id);

  const { data: myFollowRows } = user
    ? await supabase
        .from("follows")
        .select("following_id")
        .eq("follower_id", user.id)
        .in("following_id", followingIds)
    : { data: [] };
  const iFollow = new Set(myFollowRows?.map((f) => f.following_id));

  return (
    <div className="max-w-xl mx-auto">
      <Link
        href={`/u/${encodeURIComponent(profile.username)}`}
        className="text-sm text-neutral-500 hover:text-neutral-800 inline-flex items-center gap-1 mb-4"
      >
        ← {profile.username}
      </Link>
      <h1 className="text-xl font-bold mb-4">Following</h1>

      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/70 dark:border-neutral-800 shadow-sm overflow-hidden">
        {!followingRows || followingRows.length === 0 ? (
          <p className="text-neutral-400 text-center py-12">Not following anyone yet.</p>
        ) : (
          followingRows.map((f: any) => (
            <UserRow
              key={f.following_id}
              username={f.profiles?.username ?? "unknown"}
              avatarUrl={f.profiles?.avatar_url ?? null}
              userId={f.following_id}
              viewerId={user?.id ?? null}
              initialFollowing={iFollow.has(f.following_id)}
            />
          ))
        )}
      </div>
    </div>
  );
}
