import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import UserRow from "@/components/UserRow";

export default async function FollowersPage({
  params,
}: {
  params: { username: string };
}) {
  const supabase = createClient();
  const username = decodeURIComponent(params.username);

  const { data: profile } = await supabase
    .from("profiles")
    .select("id, username")
    .eq("username", username)
    .maybeSingle();

  if (!profile) notFound();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: followerRows } = await supabase
    .from("follows")
    .select("follower_id, profiles!follows_follower_id_fkey ( id, username, avatar_url )")
    .eq("following_id", profile.id)
    .order("created_at", { ascending: false });

  const followerIds = (followerRows ?? []).map((f) => f.follower_id);

  const { data: myFollowRows } = user
    ? await supabase
        .from("follows")
        .select("following_id")
        .eq("follower_id", user.id)
        .in("following_id", followerIds)
    : { data: [] };
  const iFollow = new Set(myFollowRows?.map((f) => f.following_id));

  return (
    <div className="max-w-xl mx-auto">
      <Link
        href={`/u/${encodeURIComponent(profile.username)}`}
        className="text-sm text-neutral-500 hover:text-neutral-800 inline-flex items-center gap-1 mb-4"
      >
        ← {profile.username}
      </Link>
      <h1 className="text-xl font-bold mb-4">Followers</h1>

      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/70 dark:border-neutral-800 shadow-sm overflow-hidden">
        {!followerRows || followerRows.length === 0 ? (
          <p className="text-neutral-400 text-center py-12">No followers yet.</p>
        ) : (
          followerRows.map((f: any) => (
            <UserRow
              key={f.follower_id}
              username={f.profiles?.username ?? "unknown"}
              avatarUrl={f.profiles?.avatar_url ?? null}
              userId={f.follower_id}
              viewerId={user?.id ?? null}
              initialFollowing={iFollow.has(f.follower_id)}
            />
          ))
        )}
      </div>
    </div>
  );
}
