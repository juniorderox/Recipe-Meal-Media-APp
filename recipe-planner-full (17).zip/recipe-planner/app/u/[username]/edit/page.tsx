import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import EditProfileForm from "@/components/EditProfileForm";

export default async function EditProfilePage({
  params,
}: {
  params: { username: string };
}) {
  const supabase = createClient();
  const username = decodeURIComponent(params.username);

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("id, username, display_name, bio, avatar_url")
    .eq("username", username)
    .maybeSingle();

  if (!profile) notFound();
  if (profile.id !== user.id) redirect(`/u/${encodeURIComponent(username)}`);

  return (
    <div className="max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Edit Profile</h1>
      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/70 dark:border-neutral-800 shadow-sm p-6">
        <EditProfileForm
          userId={user.id}
          initial={{
            username: profile.username,
            displayName: profile.display_name ?? "",
            bio: profile.bio ?? "",
            avatarUrl: profile.avatar_url,
          }}
        />
      </div>
    </div>
  );
}
