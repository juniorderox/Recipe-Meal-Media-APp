import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import FollowButton from "@/components/FollowButton";
import SignOutButton from "@/components/SignOutButton";

export default async function ProfilePage({
  params,
}: {
  params: { username: string };
}) {
  const supabase = createClient();
  const username = decodeURIComponent(params.username);

  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("id, username, display_name, bio, avatar_url")
    .eq("username", username)
    .maybeSingle();

  if (profileError) {
    return (
      <div className="max-w-xl mx-auto">
        <h1 className="text-xl font-bold text-red-600 mb-2">
          Couldn&apos;t load this profile
        </h1>
        <pre className="text-sm bg-red-50 text-red-700 p-4 rounded-lg whitespace-pre-wrap">
          {JSON.stringify(profileError, null, 2)}
        </pre>
      </div>
    );
  }

  if (!profile) notFound();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { count: followerCount } = await supabase
    .from("follows")
    .select("*", { count: "exact", head: true })
    .eq("following_id", profile.id);

  const { count: followingCount } = await supabase
    .from("follows")
    .select("*", { count: "exact", head: true })
    .eq("follower_id", profile.id);

  const { data: followRow } = user
    ? await supabase
        .from("follows")
        .select("following_id")
        .eq("follower_id", user.id)
        .eq("following_id", profile.id)
        .maybeSingle()
    : { data: null };

  const isOwnProfile = user?.id === profile.id;

  const { data: recipes } = await supabase
    .from("recipes")
    .select("id, title, photo_url")
    .eq("owner_id", profile.id)
    .eq("is_public", true)
    .order("created_at", { ascending: false });

  return (
    <div className="max-w-xl mx-auto">
      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/70 dark:border-neutral-800 shadow-sm p-6">
        <div className="flex items-center gap-4">
          {profile.avatar_url ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={profile.avatar_url}
              alt={profile.username}
              className="h-20 w-20 rounded-full object-cover ring-2 ring-white shadow-sm"
            />
          ) : (
            <div className="h-20 w-20 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-2xl font-semibold">
              {profile.username[0]?.toUpperCase() ?? "?"}
            </div>
          )}
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <div>
                {profile.display_name && (
                  <h1 className="text-xl font-bold leading-tight">{profile.display_name}</h1>
                )}
                <p className={profile.display_name ? "text-sm text-neutral-500" : "text-xl font-bold"}>
                  @{profile.username}
                </p>
              </div>
              {!isOwnProfile && (
                <FollowButton
                  targetUserId={profile.id}
                  userId={user?.id ?? null}
                  initialFollowing={!!followRow}
                />
              )}
              {isOwnProfile && (
                <Link
                  href={`/u/${encodeURIComponent(profile.username)}/edit`}
                  className="text-xs font-semibold px-3 py-1 rounded-full border border-neutral-300 hover:bg-neutral-50"
                >
                  Edit Profile
                </Link>
              )}
            </div>
            <div className="flex gap-4 mt-2 text-sm">
              <span>
                <strong>{recipes?.length ?? 0}</strong>{" "}
                <span className="text-neutral-500">recipes</span>
              </span>
              <Link
                href={`/u/${encodeURIComponent(profile.username)}/followers`}
                className="hover:underline"
              >
                <strong>{followerCount ?? 0}</strong>{" "}
                <span className="text-neutral-500">followers</span>
              </Link>
              <Link
                href={`/u/${encodeURIComponent(profile.username)}/following`}
                className="hover:underline"
              >
                <strong>{followingCount ?? 0}</strong>{" "}
                <span className="text-neutral-500">following</span>
              </Link>
            </div>
          </div>
        </div>
        {profile.bio && (
          <p className="text-sm text-neutral-700 mt-4 whitespace-pre-wrap">{profile.bio}</p>
        )}
        {isOwnProfile && (
          <div className="sm:hidden flex items-center gap-4 mt-4 pt-4 border-t border-neutral-100 text-sm">
            <Link href="/collections" className="text-neutral-600 hover:text-neutral-900">
              🔖 Collections
            </Link>
            <Link href="/settings" className="text-neutral-600 hover:text-neutral-900">
              ⚙️ Settings
            </Link>
            <SignOutButton />
          </div>
        )}
      </div>

      <h2 className="text-lg font-semibold mt-6 mb-3">
        {isOwnProfile ? "Your recipes" : `${profile.username}'s recipes`}
      </h2>

      {!recipes || recipes.length === 0 ? (
        <p className="text-neutral-400 text-center py-12">No recipes shared yet.</p>
      ) : (
        <div className="grid grid-cols-3 gap-1 sm:gap-3">
          {recipes.map((r) => (
            <Link
              key={r.id}
              href={`/recipes/${r.id}`}
              className="group relative block aspect-square rounded-lg sm:rounded-xl overflow-hidden bg-neutral-100"
            >
              {r.photo_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={r.photo_url}
                  alt={r.title}
                  className="h-full w-full object-cover transition-transform duration-200 group-hover:scale-105"
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center text-2xl bg-gradient-to-br from-brand-50 to-neutral-100">
                  🍽️
                </div>
              )}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
