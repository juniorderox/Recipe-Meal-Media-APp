"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function OnboardingPage() {
  const router = useRouter();
  const supabase = createClient();
  const [username, setUsername] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      setError("Something went wrong — try signing in again.");
      setSaving(false);
      return;
    }

    const clean = username.trim().toLowerCase();
    if (!/^[a-z0-9_]{3,20}$/.test(clean)) {
      setError("Username must be 3-20 characters: lowercase letters, numbers, underscores only.");
      setSaving(false);
      return;
    }

    const { error: updateError } = await supabase
      .from("profiles")
      .update({ username: clean, username_set: true })
      .eq("id", user.id);

    if (updateError) {
      if (updateError.code === "23505") {
        setError("That username is taken. Try another.");
      } else {
        setError(updateError.message);
      }
      setSaving(false);
      return;
    }

    router.push("/");
    router.refresh();
  }

  return (
    <div className="max-w-sm mx-auto py-16">
      <div className="text-center mb-6">
        <div className="text-3xl mb-1">🍲</div>
        <h1 className="text-xl font-bold">Pick your username</h1>
        <p className="text-sm text-neutral-500 mt-1">
          This is how people will find and mention you.
        </p>
      </div>

      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/70 dark:border-neutral-800 shadow-sm p-6">
        {error && (
          <p className="rounded-lg bg-red-50 text-red-700 text-sm p-3 mb-3">{error}</p>
        )}
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="flex items-center rounded-lg border border-neutral-300 px-3 py-2 focus-within:ring-2 focus-within:ring-brand-400">
            <span className="text-neutral-400">@</span>
            <input
              required
              autoFocus
              value={username}
              onChange={(e) => setUsername(e.target.value.replace(/\s/g, ""))}
              placeholder="yourname"
              className="flex-1 outline-none ml-0.5"
            />
          </div>
          <button
            type="submit"
            disabled={saving}
            className="w-full rounded-lg bg-brand-500 text-white py-2 font-medium hover:bg-brand-600 disabled:opacity-50"
          >
            {saving ? "Saving..." : "Continue"}
          </button>
        </form>
      </div>
    </div>
  );
}
