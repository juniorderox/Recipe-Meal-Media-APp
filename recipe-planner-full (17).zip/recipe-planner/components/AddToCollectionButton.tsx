"use client";

import { useEffect, useRef, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Collection = { id: string; name: string };

export default function AddToCollectionButton({
  recipeId,
  userId,
}: {
  recipeId: string;
  userId: string;
}) {
  const supabase = createClient();
  const [open, setOpen] = useState(false);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [memberOf, setMemberOf] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  async function handleOpen() {
    const willOpen = !open;
    setOpen(willOpen);
    if (willOpen && collections.length === 0) {
      setLoading(true);
      const { data: cols } = await supabase
        .from("collections")
        .select("id, name")
        .eq("owner_id", userId)
        .order("created_at", { ascending: false });
      const { data: existing } = await supabase
        .from("collection_recipes")
        .select("collection_id")
        .eq("recipe_id", recipeId);
      setCollections(cols ?? []);
      setMemberOf(new Set(existing?.map((e) => e.collection_id)));
      setLoading(false);
    }
  }

  async function toggleCollection(collectionId: string) {
    if (memberOf.has(collectionId)) {
      await supabase
        .from("collection_recipes")
        .delete()
        .eq("collection_id", collectionId)
        .eq("recipe_id", recipeId);
      setMemberOf((prev) => {
        const next = new Set(prev);
        next.delete(collectionId);
        return next;
      });
    } else {
      await supabase
        .from("collection_recipes")
        .insert({ collection_id: collectionId, recipe_id: recipeId });
      setMemberOf((prev) => new Set(prev).add(collectionId));
    }
  }

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={handleOpen}
        className="text-xs font-medium px-3 py-1.5 rounded-full border border-neutral-300 text-neutral-600 hover:bg-neutral-50"
      >
        + Add to collection
      </button>

      {open && (
        <div className="absolute left-0 mt-1 w-56 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg shadow-lg py-1 z-20 max-h-64 overflow-y-auto">
          {loading && <p className="px-4 py-2 text-sm text-neutral-400">Loading...</p>}
          {!loading && collections.length === 0 && (
            <p className="px-4 py-2 text-sm text-neutral-400">
              No collections yet — create one on the Collections page.
            </p>
          )}
          {collections.map((c) => (
            <button
              key={c.id}
              onClick={() => toggleCollection(c.id)}
              className="flex items-center gap-2 w-full text-left px-4 py-2 text-sm hover:bg-neutral-50"
            >
              <span>{memberOf.has(c.id) ? "✅" : "⬜️"}</span>
              {c.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
