"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function PostMenu({
  recipeId,
  ownerId,
  ownerUsername,
  userId,
  initialMuted = false,
  initialBlocked = false,
}: {
  recipeId: string;
  ownerId: string;
  ownerUsername?: string;
  userId: string | null;
  initialMuted?: boolean;
  initialBlocked?: boolean;
}) {
  const supabase = createClient();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [muted, setMuted] = useState(initialMuted);
  const [muteBusy, setMuteBusy] = useState(false);
  const [blocked, setBlocked] = useState(initialBlocked);
  const [blockBusy, setBlockBusy] = useState(false);
  const [reporting, setReporting] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Not signed in: nothing to show for anyone
  if (!userId) return null;

  const isOwner = userId === ownerId;

  async function handleDelete() {
    if (!confirm("Delete this recipe? This can't be undone.")) return;
    setDeleting(true);
    await supabase.from("recipes").delete().eq("id", recipeId).eq("owner_id", userId!);
    router.push("/");
    router.refresh();
  }

  async function toggleMute() {
    if (muteBusy) return;
    setMuteBusy(true);
    if (muted) {
      await supabase
        .from("muted_users")
        .delete()
        .eq("muter_id", userId!)
        .eq("muted_id", ownerId);
      setMuted(false);
    } else {
      await supabase.from("muted_users").insert({ muter_id: userId!, muted_id: ownerId });
      setMuted(true);
    }
    setMuteBusy(false);
    setOpen(false);
    router.refresh();
  }

  async function toggleBlock() {
    if (blockBusy) return;
    setBlockBusy(true);
    if (blocked) {
      await supabase
        .from("blocked_users")
        .delete()
        .eq("blocker_id", userId!)
        .eq("blocked_id", ownerId);
      setBlocked(false);
    } else {
      if (!confirm(`Block ${ownerUsername ?? "this user"}? They won't be able to follow you, and you won't see each other's posts.`)) {
        setBlockBusy(false);
        return;
      }
      await supabase.from("blocked_users").insert({ blocker_id: userId!, blocked_id: ownerId });
      // Blocking removes any follow relationship in either direction
      await supabase
        .from("follows")
        .delete()
        .or(
          `and(follower_id.eq.${userId},following_id.eq.${ownerId}),and(follower_id.eq.${ownerId},following_id.eq.${userId})`
        );
      setBlocked(true);
    }
    setBlockBusy(false);
    setOpen(false);
    router.push("/");
    router.refresh();
  }

  async function handleReport() {
    const reason = prompt("Why are you reporting this recipe? (spam, inappropriate, etc.)");
    if (!reason || !reason.trim()) return;
    setReporting(true);
    await supabase.from("reports").insert({
      reporter_id: userId!,
      reported_user_id: ownerId,
      reported_recipe_id: recipeId,
      reason: reason.trim(),
    });
    setReporting(false);
    setOpen(false);
    alert("Thanks — this has been reported.");
  }

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setOpen((o) => !o);
        }}
        className="h-8 w-8 flex items-center justify-center rounded-full hover:bg-neutral-100 text-neutral-500 text-lg leading-none"
        aria-label="Post options"
      >
        •••
      </button>

      {open && (
        <div className="absolute right-0 mt-1 w-48 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg shadow-lg py-1 z-20">
          {isOwner ? (
            <>
              <Link
                href={`/recipes/${recipeId}/edit`}
                onClick={(e) => e.stopPropagation()}
                className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50"
              >
                ✏️ Edit post
              </Link>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  handleDelete();
                }}
                disabled={deleting}
                className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-neutral-50 disabled:opacity-50"
              >
                {deleting ? "Deleting..." : "🗑️ Delete post"}
              </button>
            </>
          ) : (
            <>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  toggleMute();
                }}
                disabled={muteBusy}
                className="block w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 disabled:opacity-50"
              >
                {muted ? `🔊 Unmute ${ownerUsername ?? "user"}` : `🔇 Mute ${ownerUsername ?? "user"}`}
              </button>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  toggleBlock();
                }}
                disabled={blockBusy}
                className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-neutral-50 disabled:opacity-50"
              >
                {blocked ? `Unblock ${ownerUsername ?? "user"}` : `🚫 Block ${ownerUsername ?? "user"}`}
              </button>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  handleReport();
                }}
                disabled={reporting}
                className="block w-full text-left px-4 py-2 text-sm text-neutral-500 hover:bg-neutral-50 disabled:opacity-50"
              >
                🚩 Report post
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
