"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function FavoriteButton({
  recipeId,
  userId,
}: {
  recipeId: string;
  userId: string;
}) {
  const supabase = createClient();
  const [isFavorite, setIsFavorite] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("favorites")
      .select("recipe_id")
      .eq("user_id", userId)
      .eq("recipe_id", recipeId)
      .maybeSingle()
      .then(({ data }) => {
        setIsFavorite(!!data);
        setLoading(false);
      });
  }, [recipeId, userId]);

  async function toggle() {
    if (isFavorite) {
      await supabase
        .from("favorites")
        .delete()
        .eq("user_id", userId)
        .eq("recipe_id", recipeId);
      setIsFavorite(false);
    } else {
      await supabase.from("favorites").insert({ user_id: userId, recipe_id: recipeId });
      setIsFavorite(true);
    }
  }

  if (loading) return null;

  return (
    <button
      onClick={toggle}
      className={`text-sm font-medium rounded-lg px-3 py-1.5 border ${
        isFavorite
          ? "bg-brand-500 text-white border-brand-500"
          : "border-neutral-300 text-neutral-700"
      }`}
    >
      {isFavorite ? "🔖 Saved" : "📑 Save"}
    </button>
  );
}
