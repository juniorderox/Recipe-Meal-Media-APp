"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function LikeButton({
  recipeId,
  ownerId,
  userId,
  initialCount,
}: {
  recipeId: string;
  ownerId: string;
  userId: string | null;
  initialCount: number;
}) {
  const supabase = createClient();
  const [liked, setLiked] = useState(false);
  const [count, setCount] = useState(initialCount);
  const [loading, setLoading] = useState(!!userId);

  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }
    supabase
      .from("likes")
      .select("recipe_id")
      .eq("user_id", userId)
      .eq("recipe_id", recipeId)
      .maybeSingle()
      .then(({ data }) => {
        setLiked(!!data);
        setLoading(false);
      });
  }, [recipeId, userId]);

  async function toggle() {
    if (!userId) return;
    if (liked) {
      await supabase.from("likes").delete().eq("user_id", userId).eq("recipe_id", recipeId);
      setLiked(false);
      setCount((c) => c - 1);
    } else {
      await supabase.from("likes").insert({ user_id: userId, recipe_id: recipeId });
      setLiked(true);
      setCount((c) => c + 1);
      if (ownerId !== userId) {
        const { error: notifError } = await supabase.from("notifications").insert({
          recipient_id: ownerId,
          actor_id: userId,
          type: "like",
          recipe_id: recipeId,
        });
        if (notifError) console.error("Notification insert failed:", notifError);
      }
    }
  }

  return (
    <button
      onClick={toggle}
      disabled={!userId || loading}
      className={`flex items-center gap-1 text-sm font-medium ${
        liked ? "text-red-500" : "text-neutral-500"
      } disabled:opacity-50`}
    >
      <span>{liked ? "❤️" : "🤍"}</span>
      <span>{count}</span>
    </button>
  );
}
