"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import PostMenu from "@/components/PostMenu";
import FollowButton from "@/components/FollowButton";

function timeAgo(iso: string | null) {
  if (!iso) return "";
  const seconds = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d`;
  const weeks = Math.floor(days / 7);
  if (weeks < 5) return `${weeks}w`;
  return new Date(iso).toLocaleDateString();
}

export default function FeedPost({
  recipeId,
  title,
  description,
  photoUrl,
  ownerId,
  ownerUsername,
  ownerAvatarUrl,
  userId,
  initialLiked,
  initialLikeCount,
  commentCount,
  initialSaved,
  createdAt,
  initialFollowing = false,
  initialMuted = false,
}: {
  recipeId: string;
  title: string;
  description: string | null;
  photoUrl: string | null;
  ownerId: string;
  ownerUsername: string;
  ownerAvatarUrl: string | null;
  userId: string | null;
  initialLiked: boolean;
  initialLikeCount: number;
  commentCount: number;
  initialSaved: boolean;
  createdAt?: string | null;
  initialFollowing?: boolean;
  initialMuted?: boolean;
}) {
  const supabase = createClient();
  const [liked, setLiked] = useState(initialLiked);
  const [likeCount, setLikeCount] = useState(initialLikeCount);
  const [saved, setSaved] = useState(initialSaved);
  const [busy, setBusy] = useState(false);
  const [justLiked, setJustLiked] = useState(false);
  const [liveCommentCount, setLiveCommentCount] = useState(commentCount);

  // Live-update the comment count too
  useEffect(() => {
    const channel = supabase
      .channel(`comments:${recipeId}:${Math.random().toString(36).slice(2)}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "comments", filter: `recipe_id=eq.${recipeId}` },
        () => setLiveCommentCount((c) => c + 1)
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [recipeId]);

  // Live-update the like count when anyone (including other tabs/users) likes this post
  useEffect(() => {
    const channel = supabase
      .channel(`likes:${recipeId}:${Math.random().toString(36).slice(2)}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "likes", filter: `recipe_id=eq.${recipeId}` },
        (payload) => {
          if ((payload.new as any).user_id !== userId) {
            setLikeCount((c) => c + 1);
          }
        }
      )
      .on(
        "postgres_changes",
        { event: "DELETE", schema: "public", table: "likes", filter: `recipe_id=eq.${recipeId}` },
        (payload) => {
          if ((payload.old as any).user_id !== userId) {
            setLikeCount((c) => Math.max(0, c - 1));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [recipeId, userId]);

  async function toggleLike() {
    if (!userId || busy) return;
    setBusy(true);
    if (liked) {
      await supabase.from("likes").delete().eq("user_id", userId).eq("recipe_id", recipeId);
      setLiked(false);
      setLikeCount((c) => c - 1);
    } else {
      await supabase.from("likes").insert({ user_id: userId, recipe_id: recipeId });
      setLiked(true);
      setLikeCount((c) => c + 1);
      setJustLiked(true);
      setTimeout(() => setJustLiked(false), 300);
      if (ownerId !== userId) {
        const { error: notifError } = await supabase.from("notifications").insert({
          recipient_id: ownerId,
          actor_id: userId,
          type: "like",
          recipe_id: recipeId,
        });
        if (notifError) console.error("Notification insert failed:", notifError);
      }
    }
    setBusy(false);
  }

  async function toggleSave() {
    if (!userId || busy) return;
    setBusy(true);
    if (saved) {
      await supabase.from("favorites").delete().eq("user_id", userId).eq("recipe_id", recipeId);
      setSaved(false);
    } else {
      await supabase.from("favorites").insert({ user_id: userId, recipe_id: recipeId });
      setSaved(true);
    }
    setBusy(false);
  }

  return (
    <article className="rounded-2xl border border-neutral-200/70 dark:border-neutral-800 bg-white dark:bg-neutral-900 shadow-sm hover:shadow-md transition-shadow overflow-hidden">
      {/* Header: author */}
      <div className="flex items-center justify-between px-4 py-3">
        <Link
          href={`/u/${encodeURIComponent(ownerUsername)}`}
          className="flex items-center gap-2.5 group"
        >
          {ownerAvatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={ownerAvatarUrl}
              alt={ownerUsername}
              className="h-10 w-10 rounded-full object-cover ring-2 ring-white shadow-sm"
            />
          ) : (
            <div className="h-10 w-10 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-sm font-semibold">
              {ownerUsername[0]?.toUpperCase() ?? "?"}
            </div>
          )}
          <div>
            <div className="text-sm font-semibold group-hover:underline">
              {ownerUsername}
            </div>
            <div className="text-xs text-neutral-400">
              shared a recipe{createdAt ? ` · ${timeAgo(createdAt)}` : ""}
            </div>
          </div>
        </Link>
        <div className="flex items-center gap-2">
          <FollowButton
            targetUserId={ownerId}
            userId={userId}
            initialFollowing={initialFollowing}
          />
          <PostMenu
            recipeId={recipeId}
            ownerId={ownerId}
            ownerUsername={ownerUsername}
            userId={userId}
            initialMuted={initialMuted}
          />
        </div>
      </div>

      {/* Content */}
      <Link href={`/recipes/${recipeId}`}>
        {photoUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={photoUrl}
            alt={title}
            className="w-full h-72 object-cover bg-neutral-100"
          />
        ) : (
          <div className="w-full h-72 bg-gradient-to-br from-brand-50 to-neutral-100 flex items-center justify-center text-5xl">
            🍽️
          </div>
        )}
        <div className="px-4 pt-3">
          <h2 className="font-semibold text-base leading-snug">{title}</h2>
          {description && (
            <p className="text-sm text-neutral-500 mt-0.5 line-clamp-2">{description}</p>
          )}
        </div>
      </Link>

      {/* Counts row */}
      {(likeCount > 0 || liveCommentCount > 0) && (
        <div className="px-4 pt-2.5 flex items-center justify-between text-xs text-neutral-400">
          <span className={`transition-transform ${justLiked ? "scale-125" : "scale-100"}`}>
            {likeCount > 0 ? `❤️ ${likeCount}` : ""}
          </span>
          <Link href={`/recipes/${recipeId}#comments`} className="hover:underline">
            {liveCommentCount > 0 ? `${liveCommentCount} comment${liveCommentCount === 1 ? "" : "s"}` : ""}
          </Link>
        </div>
      )}

      {/* Action bar */}
      <div className="mt-2 border-t border-neutral-100 px-2 py-1 flex items-center justify-around">
        <button
          onClick={toggleLike}
          disabled={!userId || busy}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-medium transition-colors hover:bg-neutral-50 disabled:opacity-40 disabled:cursor-not-allowed ${
            liked ? "text-red-500" : "text-neutral-600"
          }`}
        >
          <span className={justLiked ? "animate-bounce" : ""}>{liked ? "❤️" : "🤍"}</span>
          Like
        </button>
        <Link
          href={`/recipes/${recipeId}#comments`}
          className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-medium text-neutral-600 hover:bg-neutral-50 transition-colors"
        >
          💬 Comment
        </Link>
        <button
          onClick={toggleSave}
          disabled={!userId || busy}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-medium transition-colors hover:bg-neutral-50 disabled:opacity-40 disabled:cursor-not-allowed ${
            saved ? "text-brand-600" : "text-neutral-600"
          }`}
        >
          <span>{saved ? "🔖" : "📑"}</span> Save
        </button>
      </div>
    </article>
  );
}
