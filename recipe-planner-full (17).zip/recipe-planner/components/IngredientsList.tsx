"use client";

import { useState } from "react";

type Ingredient = {
  quantity: number | null;
  unit: string | null;
  note: string | null;
  name: string;
};

export default function IngredientsList({
  baseServings,
  ingredients,
}: {
  baseServings: number;
  ingredients: Ingredient[];
}) {
  const [servings, setServings] = useState(baseServings || 1);

  function formatQty(qty: number | null) {
    if (qty == null) return null;
    const scaled = (qty * servings) / (baseServings || 1);
    // Trim to at most 2 decimal places, drop trailing zeros
    return Math.round(scaled * 100) / 100;
  }

  return (
    <div>
      <div className="flex items-center gap-3 mb-3">
        <span className="text-sm text-neutral-500">Servings</span>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setServings((s) => Math.max(1, s - 1))}
            className="h-7 w-7 rounded-full border border-neutral-300 text-neutral-600 hover:bg-neutral-50"
          >
            −
          </button>
          <span className="w-6 text-center font-medium">{servings}</span>
          <button
            type="button"
            onClick={() => setServings((s) => s + 1)}
            className="h-7 w-7 rounded-full border border-neutral-300 text-neutral-600 hover:bg-neutral-50"
          >
            +
          </button>
        </div>
      </div>
      <ul className="list-disc list-inside space-y-1 text-neutral-800 dark:text-neutral-200 text-sm">
        {ingredients.map((ing, i) => {
          const qty = formatQty(ing.quantity);
          return (
            <li key={i}>
              {qty != null ? `${qty} ` : ""}
              {ing.unit ? `${ing.unit} ` : ""}
              {ing.name}
              {ing.note ? ` (${ing.note})` : ""}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
