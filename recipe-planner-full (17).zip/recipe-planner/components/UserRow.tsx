import Link from "next/link";
import FollowButton from "@/components/FollowButton";

export default function UserRow({
  username,
  avatarUrl,
  userId,
  viewerId,
  initialFollowing,
}: {
  username: string;
  avatarUrl: string | null;
  userId: string;
  viewerId: string | null;
  initialFollowing: boolean;
}) {
  return (
    <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-100 last:border-0">
      <Link href={`/u/${encodeURIComponent(username)}`} className="flex items-center gap-3">
        {avatarUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={avatarUrl} alt={username} className="h-10 w-10 rounded-full object-cover" />
        ) : (
          <div className="h-10 w-10 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-sm font-semibold">
            {username[0]?.toUpperCase() ?? "?"}
          </div>
        )}
        <span className="text-sm font-semibold">{username}</span>
      </Link>
      <FollowButton
        targetUserId={userId}
        userId={viewerId}
        initialFollowing={initialFollowing}
      />
    </div>
  );
}
