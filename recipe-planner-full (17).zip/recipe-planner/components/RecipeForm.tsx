"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

type IngredientRow = { name: string; quantity: string; unit: string };
type Tag = { id: string; name: string; category: string };

export default function RecipeForm({
  mode = "create",
  recipeId,
  initial,
}: {
  mode?: "create" | "edit";
  recipeId?: string;
  initial?: {
    title: string;
    description: string;
    cookTime: string;
    servings: string;
    steps: string[];
    ingredients: IngredientRow[];
    photoUrls: string[];
    tagIds: string[];
  };
}) {
  const router = useRouter();
  const supabase = createClient();

  const [title, setTitle] = useState(initial?.title ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [cookTime, setCookTime] = useState(initial?.cookTime ?? "");
  const [servings, setServings] = useState(initial?.servings ?? "4");
  const [steps, setSteps] = useState<string[]>(initial?.steps ?? [""]);
  const [ingredients, setIngredients] = useState<IngredientRow[]>(
    initial?.ingredients ?? [{ name: "", quantity: "", unit: "" }]
  );

  // Existing photo URLs (edit mode) the user can keep or remove, plus newly picked files
  const [existingPhotoUrls, setExistingPhotoUrls] = useState<string[]>(
    initial?.photoUrls ?? []
  );
  const [newPhotoFiles, setNewPhotoFiles] = useState<File[]>([]);
  const [newPhotoPreviews, setNewPhotoPreviews] = useState<string[]>([]);

  const [allTags, setAllTags] = useState<Tag[]>([]);
  const [selectedTagIds, setSelectedTagIds] = useState<Set<string>>(
    new Set(initial?.tagIds ?? [])
  );

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    supabase
      .from("tags")
      .select("id, name, category")
      .order("category")
      .then(({ data }) => setAllTags(data ?? []));
  }, []);

  function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (files.length === 0) return;
    setNewPhotoFiles((prev) => [...prev, ...files]);
    setNewPhotoPreviews((prev) => [...prev, ...files.map((f) => URL.createObjectURL(f))]);
  }

  function removeExistingPhoto(url: string) {
    setExistingPhotoUrls((prev) => prev.filter((u) => u !== url));
  }

  function removeNewPhoto(index: number) {
    setNewPhotoFiles((prev) => prev.filter((_, i) => i !== index));
    setNewPhotoPreviews((prev) => prev.filter((_, i) => i !== index));
  }

  function toggleTag(id: string) {
    setSelectedTagIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function updateStep(i: number, value: string) {
    setSteps((prev) => prev.map((s, idx) => (idx === i ? value : s)));
  }

  function updateIngredient(i: number, field: keyof IngredientRow, value: string) {
    setIngredients((prev) =>
      prev.map((row, idx) => (idx === i ? { ...row, [field]: value } : row))
    );
  }

  async function linkIngredients(targetRecipeId: string) {
    for (const row of ingredients) {
      if (!row.name.trim()) continue;

      const { data: ingredient, error: ingErr } = await supabase
        .from("ingredients")
        .upsert({ name: row.name.trim().toLowerCase() }, { onConflict: "name" })
        .select()
        .single();

      if (ingErr || !ingredient) continue;

      await supabase.from("recipe_ingredients").insert({
        recipe_id: targetRecipeId,
        ingredient_id: ingredient.id,
        quantity: row.quantity ? parseFloat(row.quantity) : null,
        unit: row.unit || null,
      });
    }
  }

  async function linkTags(targetRecipeId: string) {
    await supabase.from("recipe_tags").delete().eq("recipe_id", targetRecipeId);
    if (selectedTagIds.size === 0) return;
    await supabase.from("recipe_tags").insert(
      [...selectedTagIds].map((tagId) => ({ recipe_id: targetRecipeId, tag_id: tagId }))
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      setError("You need to be signed in to save a recipe.");
      setSaving(false);
      return;
    }

    // Upload any newly picked photos
    const uploadedUrls: string[] = [];
    for (const file of newPhotoFiles) {
      const ext = file.name.split(".").pop();
      const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
      const { error: uploadError } = await supabase.storage
        .from("recipe-photos")
        .upload(path, file);

      if (uploadError) {
        setError(`Photo upload failed: ${uploadError.message}`);
        setSaving(false);
        return;
      }
      const { data: publicUrlData } = supabase.storage
        .from("recipe-photos")
        .getPublicUrl(path);
      uploadedUrls.push(publicUrlData.publicUrl);
    }

    const allPhotoUrls = [...existingPhotoUrls, ...uploadedUrls];
    const coverPhotoUrl = allPhotoUrls[0] ?? null;

    const payload = {
      title,
      description,
      photo_url: coverPhotoUrl,
      cook_time_minutes: cookTime ? parseInt(cookTime, 10) : null,
      servings: parseInt(servings, 10) || 4,
      steps: steps.filter((s) => s.trim() !== ""),
    };

    let targetId = recipeId;

    if (mode === "edit" && recipeId) {
      const { error: updateError } = await supabase
        .from("recipes")
        .update(payload)
        .eq("id", recipeId)
        .eq("owner_id", user.id);

      if (updateError) {
        setError(updateError.message);
        setSaving(false);
        return;
      }

      await supabase.from("recipe_ingredients").delete().eq("recipe_id", recipeId);
      await linkIngredients(recipeId);
    } else {
      const { data: recipe, error: recipeError } = await supabase
        .from("recipes")
        .insert({ owner_id: user.id, ...payload })
        .select()
        .single();

      if (recipeError || !recipe) {
        setError(recipeError?.message ?? "Failed to save recipe.");
        setSaving(false);
        return;
      }
      targetId = recipe.id;
      await linkIngredients(recipe.id);
    }

    if (!targetId) {
      setSaving(false);
      return;
    }

    // Replace the photo gallery rows to match the current set
    await supabase.from("recipe_photos").delete().eq("recipe_id", targetId);
    if (allPhotoUrls.length > 0) {
      await supabase.from("recipe_photos").insert(
        allPhotoUrls.map((url, i) => ({ recipe_id: targetId, url, position: i }))
      );
    }

    await linkTags(targetId);

    setSaving(false);
    router.push(`/recipes/${targetId}`);
    router.refresh();
  }

  const tagsByCategory = allTags.reduce<Record<string, Tag[]>>((acc, tag) => {
    (acc[tag.category] ??= []).push(tag);
    return acc;
  }, {});

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl">
      {error && (
        <p className="rounded-lg bg-red-50 text-red-700 text-sm p-3">{error}</p>
      )}

      <div>
        <label className="block text-sm font-medium mb-1">Photos</label>
        <div className="flex flex-wrap gap-2 mb-2">
          {existingPhotoUrls.map((url) => (
            <div key={url} className="relative w-24 h-24">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={url} alt="" className="w-24 h-24 object-cover rounded-lg border" />
              <button
                type="button"
                onClick={() => removeExistingPhoto(url)}
                className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-neutral-900 text-white text-xs"
              >
                ×
              </button>
            </div>
          ))}
          {newPhotoPreviews.map((url, i) => (
            <div key={url} className="relative w-24 h-24">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={url} alt="" className="w-24 h-24 object-cover rounded-lg border" />
              <button
                type="button"
                onClick={() => removeNewPhoto(i)}
                className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-neutral-900 text-white text-xs"
              >
                ×
              </button>
            </div>
          ))}
        </div>
        <input
          type="file"
          accept="image/*"
          multiple
          onChange={handlePhotoChange}
          className="text-sm"
        />
        <p className="text-xs text-neutral-400 mt-1">First photo becomes the cover.</p>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Title</label>
        <input
          required
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full rounded-lg border border-neutral-300 px-3 py-2"
          placeholder="Khao Soi"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Description</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full rounded-lg border border-neutral-300 px-3 py-2"
          rows={2}
        />
      </div>

      <div className="flex gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Cook time (min)</label>
          <input
            type="number"
            value={cookTime}
            onChange={(e) => setCookTime(e.target.value)}
            className="w-32 rounded-lg border border-neutral-300 px-3 py-2"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Servings</label>
          <input
            type="number"
            value={servings}
            onChange={(e) => setServings(e.target.value)}
            className="w-32 rounded-lg border border-neutral-300 px-3 py-2"
          />
        </div>
      </div>

      {Object.keys(tagsByCategory).length > 0 && (
        <div>
          <label className="block text-sm font-medium mb-2">Tags</label>
          <div className="space-y-2">
            {Object.entries(tagsByCategory).map(([category, tags]) => (
              <div key={category}>
                <div className="text-xs text-neutral-400 uppercase mb-1">{category}</div>
                <div className="flex flex-wrap gap-1.5">
                  {tags.map((tag) => (
                    <button
                      key={tag.id}
                      type="button"
                      onClick={() => toggleTag(tag.id)}
                      className={`text-xs px-3 py-1 rounded-full border transition-colors ${
                        selectedTagIds.has(tag.id)
                          ? "bg-brand-500 text-white border-brand-500"
                          : "border-neutral-300 text-neutral-600 hover:bg-neutral-50"
                      }`}
                    >
                      {tag.name}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div>
        <label className="block text-sm font-medium mb-2">Ingredients</label>
        <div className="space-y-2">
          {ingredients.map((row, i) => (
            <div key={i} className="flex gap-2">
              <input
                placeholder="Ingredient"
                value={row.name}
                onChange={(e) => updateIngredient(i, "name", e.target.value)}
                className="flex-1 rounded-lg border border-neutral-300 px-3 py-2"
              />
              <input
                placeholder="Qty"
                value={row.quantity}
                onChange={(e) => updateIngredient(i, "quantity", e.target.value)}
                className="w-20 rounded-lg border border-neutral-300 px-3 py-2"
              />
              <input
                placeholder="Unit"
                value={row.unit}
                onChange={(e) => updateIngredient(i, "unit", e.target.value)}
                className="w-24 rounded-lg border border-neutral-300 px-3 py-2"
              />
            </div>
          ))}
        </div>
        <button
          type="button"
          onClick={() => setIngredients((p) => [...p, { name: "", quantity: "", unit: "" }])}
          className="mt-2 text-sm text-brand-600 font-medium"
        >
          + Add ingredient
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Steps</label>
        <div className="space-y-2">
          {steps.map((s, i) => (
            <textarea
              key={i}
              value={s}
              onChange={(e) => updateStep(i, e.target.value)}
              placeholder={`Step ${i + 1}`}
              className="w-full rounded-lg border border-neutral-300 px-3 py-2"
              rows={2}
            />
          ))}
        </div>
        <button
          type="button"
          onClick={() => setSteps((p) => [...p, ""])}
          className="mt-2 text-sm text-brand-600 font-medium"
        >
          + Add step
        </button>
      </div>

      <button
        type="submit"
        disabled={saving}
        className="rounded-lg bg-brand-500 text-white px-5 py-2.5 font-medium hover:bg-brand-600 disabled:opacity-50"
      >
        {saving ? "Saving..." : mode === "edit" ? "Save Changes" : "Save Recipe"}
      </button>
    </form>
  );
}
