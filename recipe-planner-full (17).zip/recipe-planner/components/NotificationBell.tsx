"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

type Notification = {
  id: string;
  type: "like" | "comment" | "follow";
  recipe_id: string | null;
  read: boolean;
  created_at: string;
  actor: { username: string; avatar_url: string | null } | null;
  recipe_title: string | null;
};

const ICON: Record<Notification["type"], string> = {
  like: "❤️",
  comment: "💬",
  follow: "➕",
};

function verb(type: Notification["type"]) {
  if (type === "like") return "liked your recipe";
  if (type === "comment") return "commented on your recipe";
  return "started following you";
}

export default function NotificationBell({
  userId,
  initialNotifications,
}: {
  userId: string;
  initialNotifications: Notification[];
}) {
  const supabase = createClient();
  const [notifications, setNotifications] = useState(initialNotifications);
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter((n) => !n.read).length;

  useEffect(() => {
    const channel = supabase
      .channel(`notifications:${userId}:${Math.random().toString(36).slice(2)}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "notifications",
          filter: `recipient_id=eq.${userId}`,
        },
        async (payload) => {
          const row = payload.new as any;
          const [{ data: actor }, recipeRes] = await Promise.all([
            supabase
              .from("profiles")
              .select("username, avatar_url")
              .eq("id", row.actor_id)
              .maybeSingle(),
            row.recipe_id
              ? supabase.from("recipes").select("title").eq("id", row.recipe_id).maybeSingle()
              : Promise.resolve({ data: null }),
          ]);
          setNotifications((prev) => [
            {
              id: row.id,
              type: row.type,
              recipe_id: row.recipe_id,
              read: false,
              created_at: row.created_at,
              actor: actor ?? null,
              recipe_title: (recipeRes as any).data?.title ?? null,
            },
            ...prev,
          ]);
        }
      )
      .subscribe((status) => {
        if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") {
          console.error("Notifications realtime subscription failed:", status);
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  async function handleOpen() {
    const willOpen = !open;
    setOpen(willOpen);
    if (willOpen && unreadCount > 0) {
      const unreadIds = notifications.filter((n) => !n.read).map((n) => n.id);
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
      await supabase.from("notifications").update({ read: true }).in("id", unreadIds);
    }
  }

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={handleOpen}
        className="relative h-9 w-9 flex items-center justify-center rounded-full hover:bg-neutral-100 text-lg"
        aria-label="Notifications"
      >
        🔔
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[10px] font-bold h-4 min-w-[16px] px-1 rounded-full flex items-center justify-center">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-[min(20rem,90vw)] max-h-96 overflow-y-auto bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl shadow-lg z-30">
          <div className="px-4 py-3 border-b border-neutral-100 font-semibold text-sm">
            Notifications
          </div>
          {notifications.length === 0 ? (
            <p className="px-4 py-6 text-sm text-neutral-400 text-center">
              No notifications yet.
            </p>
          ) : (
            notifications.map((n) => (
              <Link
                key={n.id}
                href={n.recipe_id ? `/recipes/${n.recipe_id}` : "#"}
                onClick={() => setOpen(false)}
                className={`flex items-start gap-3 px-4 py-3 text-sm hover:bg-neutral-50 border-b border-neutral-50 last:border-0 ${
                  !n.read ? "bg-brand-50/40" : ""
                }`}
              >
                <span className="text-base">{ICON[n.type]}</span>
                <span className="text-neutral-700">
                  <span className="font-semibold">{n.actor?.username ?? "Someone"}</span>{" "}
                  {verb(n.type)}
                  {n.recipe_title ? ` "${n.recipe_title}"` : ""}
                </span>
              </Link>
            ))
          )}
        </div>
      )}
    </div>
  );
}
