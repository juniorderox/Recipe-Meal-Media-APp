"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function FollowButton({
  targetUserId,
  userId,
  initialFollowing,
}: {
  targetUserId: string;
  userId: string | null;
  initialFollowing: boolean;
}) {
  const supabase = createClient();
  const [following, setFollowing] = useState(initialFollowing);
  const [busy, setBusy] = useState(false);

  // Don't show a follow button for yourself, or when signed out
  if (!userId || userId === targetUserId) return null;

  async function toggle() {
    if (busy) return;
    setBusy(true);
    if (following) {
      await supabase
        .from("follows")
        .delete()
        .eq("follower_id", userId)
        .eq("following_id", targetUserId);
      setFollowing(false);
    } else {
      await supabase
        .from("follows")
        .insert({ follower_id: userId, following_id: targetUserId });
      setFollowing(true);
      const { error: notifError } = await supabase.from("notifications").insert({
        recipient_id: targetUserId,
        actor_id: userId,
        type: "follow",
        recipe_id: null,
      });
      if (notifError) console.error("Notification insert failed:", notifError);
    }
    setBusy(false);
  }

  return (
    <button
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        toggle();
      }}
      disabled={busy}
      className={`text-xs font-semibold px-3 py-1 rounded-full transition-colors disabled:opacity-50 ${
        following
          ? "bg-neutral-100 text-neutral-600 hover:bg-neutral-200"
          : "bg-brand-500 text-white hover:bg-brand-600"
      }`}
    >
      {following ? "Following" : "Follow"}
    </button>
  );
}
