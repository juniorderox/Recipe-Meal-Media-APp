"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

type Comment = {
  id: string;
  body: string;
  created_at: string;
  user_id: string;
  profiles: { username: string } | null;
};

export default function Comments({
  recipeId,
  recipeOwnerId,
  userId,
}: {
  recipeId: string;
  recipeOwnerId: string;
  userId: string | null;
}) {
  const supabase = createClient();
  const [comments, setComments] = useState<Comment[]>([]);
  const [body, setBody] = useState("");
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    supabase
      .from("comments")
      .select("id, body, created_at, user_id, profiles ( username )")
      .eq("recipe_id", recipeId)
      .order("created_at", { ascending: true })
      .then(({ data }) => setComments((data as any) ?? []));
  }, [recipeId]);

  async function submitComment(e: React.FormEvent) {
    e.preventDefault();
    if (!userId || !body.trim()) return;
    setPosting(true);

    const { data, error } = await supabase
      .from("comments")
      .insert({ recipe_id: recipeId, user_id: userId, body: body.trim() })
      .select("id, body, created_at, user_id, profiles ( username )")
      .single();

    if (!error && data) {
      setComments((prev) => [...prev, data as any]);
      setBody("");
      if (recipeOwnerId !== userId) {
        const { error: notifError } = await supabase.from("notifications").insert({
          recipient_id: recipeOwnerId,
          actor_id: userId,
          type: "comment",
          recipe_id: recipeId,
        });
        if (notifError) console.error("Notification insert failed:", notifError);
      }
    }
    setPosting(false);
  }

  return (
    <div>
      <h2 id="comments" className="text-lg font-semibold mt-6 mb-2">
        Comments ({comments.length})
      </h2>

      <div className="space-y-3 mb-4">
        {comments.map((c) => (
          <div key={c.id} className="text-sm">
            {c.profiles?.username ? (
              <Link
                href={`/u/${encodeURIComponent(c.profiles.username)}`}
                className="font-medium hover:underline"
              >
                {c.profiles.username}
              </Link>
            ) : (
              <span className="font-medium">Someone</span>
            )}{" "}
            <span className="text-neutral-700">{c.body}</span>
          </div>
        ))}
        {comments.length === 0 && (
          <p className="text-sm text-neutral-400">No comments yet.</p>
        )}
      </div>

      {userId ? (
        <form onSubmit={submitComment} className="flex gap-2">
          <input
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="Add a comment..."
            className="flex-1 rounded-lg border border-neutral-300 px-3 py-2 text-sm"
          />
          <button
            type="submit"
            disabled={posting || !body.trim()}
            className="rounded-lg bg-neutral-900 text-white px-4 py-2 text-sm disabled:opacity-50"
          >
            Post
          </button>
        </form>
      ) : (
        <p className="text-sm text-neutral-400">Sign in to leave a comment.</p>
      )}
    </div>
  );
}
