"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function BottomNav({
  userId,
  username,
  avatarUrl,
}: {
  userId: string | null;
  username: string | null;
  avatarUrl: string | null;
}) {
  const pathname = usePathname();

  const isActive = (path: string) =>
    path === "/" ? pathname === "/" : pathname.startsWith(path);

  const iconClass = (active: boolean) =>
    `flex flex-col items-center justify-center gap-0.5 flex-1 py-2 text-xl ${
      active ? "text-brand-600" : "text-neutral-400"
    }`;

  return (
    <nav className="sm:hidden fixed bottom-0 inset-x-0 z-30 bg-white/90 dark:bg-neutral-900/90 backdrop-blur-md border-t border-neutral-200/70 dark:border-neutral-800 flex items-center">
      <Link href="/" className={iconClass(isActive("/") && !isActive("/recipes") && !isActive("/saved") && !isActive("/search") && !isActive("/u"))}>
        🏠
      </Link>
      <Link href="/recipes" className={iconClass(isActive("/recipes") && !pathname.includes("/new"))}>
        📖
      </Link>
      <Link href="/recipes/new" className={iconClass(pathname === "/recipes/new")}>
        ➕
      </Link>
      {userId && (
        <Link href="/saved" className={iconClass(isActive("/saved"))}>
          🔖
        </Link>
      )}
      {userId ? (
        <Link
          href={username ? `/u/${encodeURIComponent(username)}` : "/login"}
          className={`flex flex-col items-center justify-center flex-1 py-2 ${
            isActive("/u") ? "opacity-100" : "opacity-60"
          }`}
        >
          {avatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={avatarUrl}
              alt="Profile"
              className={`h-6 w-6 rounded-full object-cover ${
                isActive("/u") ? "ring-2 ring-brand-500" : ""
              }`}
            />
          ) : (
            <div className="h-6 w-6 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-[10px] font-semibold">
              {username?.[0]?.toUpperCase() ?? "?"}
            </div>
          )}
        </Link>
      ) : (
        <Link href="/login" className={iconClass(isActive("/login"))}>
          👤
        </Link>
      )}
    </nav>
  );
}
