"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function EditProfileForm({
  userId,
  initial,
}: {
  userId: string;
  initial: {
    username: string;
    displayName: string;
    bio: string;
    avatarUrl: string | null;
  };
}) {
  const router = useRouter();
  const supabase = createClient();

  const [username, setUsername] = useState(initial.username);
  const [displayName, setDisplayName] = useState(initial.displayName);
  const [bio, setBio] = useState(initial.bio);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(initial.avatarUrl);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function handleAvatarChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setAvatarFile(file);
    setAvatarPreview(URL.createObjectURL(file));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    let avatarUrl = initial.avatarUrl;

    if (avatarFile) {
      const ext = avatarFile.name.split(".").pop();
      const path = `${userId}/${crypto.randomUUID()}.${ext}`;
      const { error: uploadError } = await supabase.storage
        .from("avatars")
        .upload(path, avatarFile);

      if (uploadError) {
        setError(`Photo upload failed: ${uploadError.message}`);
        setSaving(false);
        return;
      }

      const { data: publicUrlData } = supabase.storage.from("avatars").getPublicUrl(path);
      avatarUrl = publicUrlData.publicUrl;
    }

    const { error: updateError } = await supabase
      .from("profiles")
      .update({
        username: username.trim(),
        display_name: displayName.trim() || null,
        bio: bio.trim() || null,
        avatar_url: avatarUrl,
      })
      .eq("id", userId);

    if (updateError) {
      if (updateError.code === "23505") {
        setError("That username is already taken. Try another one.");
      } else {
        setError(updateError.message);
      }
      setSaving(false);
      return;
    }

    setSaving(false);
    router.push(`/u/${encodeURIComponent(username.trim())}`);
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {error && (
        <p className="rounded-lg bg-red-50 text-red-700 text-sm p-3">{error}</p>
      )}

      <div className="flex items-center gap-4">
        {avatarPreview ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={avatarPreview}
            alt="Preview"
            className="h-20 w-20 rounded-full object-cover ring-2 ring-white shadow-sm"
          />
        ) : (
          <div className="h-20 w-20 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-2xl font-semibold">
            {username[0]?.toUpperCase() ?? "?"}
          </div>
        )}
        <div>
          <label className="block text-sm font-medium mb-1">Profile photo</label>
          <input type="file" accept="image/*" onChange={handleAvatarChange} className="text-sm" />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Display name</label>
        <input
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
          placeholder="Your name"
          className="w-full rounded-lg border border-neutral-300 px-3 py-2"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Username</label>
        <div className="flex items-center rounded-lg border border-neutral-300 px-3 py-2 focus-within:ring-2 focus-within:ring-brand-400">
          <span className="text-neutral-400">@</span>
          <input
            required
            value={username}
            onChange={(e) => setUsername(e.target.value.replace(/\s/g, ""))}
            className="flex-1 outline-none ml-0.5"
          />
        </div>
        <p className="text-xs text-neutral-400 mt-1">
          Changing this changes your profile URL and everyone's links to it.
        </p>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Bio</label>
        <textarea
          value={bio}
          onChange={(e) => setBio(e.target.value.slice(0, 150))}
          rows={3}
          maxLength={150}
          placeholder="Tell people about yourself..."
          className="w-full rounded-lg border border-neutral-300 px-3 py-2"
        />
        <p className="text-xs text-neutral-400 mt-1">{bio.length}/150</p>
      </div>

      <button
        type="submit"
        disabled={saving}
        className="rounded-lg bg-brand-500 text-white px-5 py-2.5 font-medium hover:bg-brand-600 disabled:opacity-50"
      >
        {saving ? "Saving..." : "Save Changes"}
      </button>
    </form>
  );
}
